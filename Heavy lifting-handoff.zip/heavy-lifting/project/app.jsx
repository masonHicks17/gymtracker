// app.jsx — Workout logger redesign
const { useState, useEffect, useRef, useMemo } = React;

// ─────────────────────────────────────────────────────────────
// Tweak defaults
// ─────────────────────────────────────────────────────────────
const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "accent": "orange",
  "theme": "dark",
  "variant": "synthesis",
  "density": "comfortable",
  "showTimer": false
}/*EDITMODE-END*/;

// ─────────────────────────────────────────────────────────────
// Design tokens per theme
// ─────────────────────────────────────────────────────────────
const ACCENTS = {
  lime:   { hue: 'oklch(0.88 0.22 128)',  solid: '#C8F751', ink: '#0B1504' },
  orange: { hue: 'oklch(0.78 0.17 55)',   solid: '#FF9E5E', ink: '#1A0A00' },
  violet: { hue: 'oklch(0.72 0.18 295)',  solid: '#B79BFF', ink: '#0E0521' },
  coral:  { hue: 'oklch(0.75 0.18 25)',   solid: '#FF7A6B', ink: '#1F0505' },
  cyan:   { hue: 'oklch(0.82 0.14 210)',  solid: '#6BD5F0', ink: '#002028' },
};

function getTheme(mode) {
  if (mode === 'light') {
    return {
      bg:      '#F4F2EE',
      surface: '#FFFFFF',
      surface2:'#EAE7E1',
      ink:     '#0C0C0C',
      ink2:    '#5A5A5A',
      ink3:    '#9A9A9A',
      line:    'rgba(0,0,0,0.08)',
      rowBg:   '#FFFFFF',
    };
  }
  return {
    bg:      '#0A0A0A',
    surface: '#141414',
    surface2:'#1E1E1E',
    ink:     '#F4F2EE',
    ink2:    'rgba(244,242,238,0.58)',
    ink3:    'rgba(244,242,238,0.32)',
    line:    'rgba(255,255,255,0.07)',
    rowBg:   '#161616',
  };
}

// ─────────────────────────────────────────────────────────────
// Icons
// ─────────────────────────────────────────────────────────────
const Icon = {
  close: (c) => <svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M3 3l10 10M13 3L3 13" stroke={c} strokeWidth="1.75" strokeLinecap="round"/></svg>,
  check: (c) => <svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M3 8.5l3.5 3.5L13 5" stroke={c} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>,
  info:  (c) => <svg width="14" height="14" viewBox="0 0 14 14" fill="none"><circle cx="7" cy="7" r="6" stroke={c} strokeWidth="1.25"/><path d="M7 6v4M7 4v.5" stroke={c} strokeWidth="1.5" strokeLinecap="round"/></svg>,
  minus: (c, s=14) => <svg width={s} height={s} viewBox="0 0 14 14" fill="none"><path d="M3 7h8" stroke={c} strokeWidth="1.75" strokeLinecap="round"/></svg>,
  plus:  (c, s=14) => <svg width={s} height={s} viewBox="0 0 14 14" fill="none"><path d="M7 3v8M3 7h8" stroke={c} strokeWidth="1.75" strokeLinecap="round"/></svg>,
  play:  (c) => <svg width="14" height="14" viewBox="0 0 14 14" fill={c}><path d="M3 2l9 5-9 5V2z"/></svg>,
  pause: (c) => <svg width="14" height="14" viewBox="0 0 14 14" fill={c}><rect x="3" y="2" width="3" height="10" rx="0.5"/><rect x="8" y="2" width="3" height="10" rx="0.5"/></svg>,
  reset: (c) => <svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M11.5 5A5 5 0 102 7.5" stroke={c} strokeWidth="1.5" strokeLinecap="round"/><path d="M11.5 2v3h-3" stroke={c} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/></svg>,
  note:  (c) => <svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M2 3h10M2 7h10M2 11h6" stroke={c} strokeWidth="1.25" strokeLinecap="round"/></svg>,
  chart: (c) => <svg width="14" height="14" viewBox="0 0 14 14" fill={c}><rect x="1" y="8" width="2.5" height="5" rx="0.5"/><rect x="5.75" y="5" width="2.5" height="8" rx="0.5"/><rect x="10.5" y="2" width="2.5" height="11" rx="0.5"/></svg>,
  dumbbell: (c) => <svg width="16" height="16" viewBox="0 0 16 16" fill="none"><rect x="0.5" y="5" width="2" height="6" rx="0.6" fill={c}/><rect x="13.5" y="5" width="2" height="6" rx="0.6" fill={c}/><rect x="2.5" y="6.25" width="1.5" height="3.5" rx="0.4" fill={c}/><rect x="12" y="6.25" width="1.5" height="3.5" rx="0.4" fill={c}/><rect x="4" y="7.25" width="8" height="1.5" rx="0.5" fill={c}/></svg>,
  swap: (c) => <svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M2 4h9l-2-2M12 10H3l2 2" stroke={c} strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round"/></svg>,
};

// ─────────────────────────────────────────────────────────────
// Mono + display type
// ─────────────────────────────────────────────────────────────
// These defer to CSS vars so Tweaks can swap fonts live. The fallback stack
// kicks in only if the host page hasn't defined --app-display / --app-sans.
const DISPLAY = `var(--app-display, 'Fraunces', 'Times New Roman', serif)`;
const MONO    = `var(--app-mono, 'JetBrains Mono', 'SF Mono', ui-monospace, monospace)`;
const SANS    = `var(--app-sans, 'Inter', -apple-system, system-ui, sans-serif)`;

// Radius scale — used by all-screens. Returns a calc() so inline numeric
// border-radius tracks --radius-scale live. Keeps existing call sites readable.
function rs(n) { return `calc(${n}px * var(--radius-scale, 1))`; }

// ─────────────────────────────────────────────────────────────
// Top stats strip
// ─────────────────────────────────────────────────────────────
function StatsStrip({ theme, accent }) {
  const cells = [
    { label: 'PR 1RM',   value: '155',    sub: 'lb · best' },
    { label: 'Avg W.',   value: '71',     sub: 'lb · last 6' },
    { label: 'Volume',   value: '1,686',  sub: 'lb · last 6' },
    { label: 'Today',    value: '75',     sub: 'lb · avg',    hi: true },
    { label: 'Total',    value: '1,785',  sub: 'lb · today',  hi: true },
  ];
  return (
    <div style={{
      display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)',
      padding: '4px 20px 22px', gap: 0,
      borderBottom: `1px solid ${theme.line}`,
    }}>
      {cells.map((c, i) => (
        <div key={i} style={{
          padding: '0 6px',
          borderLeft: i > 0 ? `1px solid ${theme.line}` : 'none',
          display: 'flex', flexDirection: 'column', gap: 3,
        }}>
          <div style={{
            fontFamily: MONO, fontSize: 9.5, letterSpacing: 0.7,
            textTransform: 'uppercase',
            color: c.hi ? accent.solid : theme.ink3,
          }}>{c.label}</div>
          <div style={{
            fontFamily: DISPLAY, fontSize: 22, fontWeight: 400,
            color: theme.ink, lineHeight: 1, letterSpacing: -0.5,
            fontFeatureSettings: '"tnum"',
          }}>{c.value}</div>
          <div style={{
            fontFamily: MONO, fontSize: 8.5, color: theme.ink3,
            letterSpacing: 0.3,
          }}>{c.sub}</div>
        </div>
      ))}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Set row — editorial variant (the hero)
// ─────────────────────────────────────────────────────────────
function SetRow({ set, index, onUpdate, onComplete, theme, accent, density }) {
  const [activeField, setActiveField] = useState(null);
  const complete = set.complete;
  const rowPad = density === 'compact' ? '12px 14px' : '16px 16px';

  const bump = (field, delta) => {
    onUpdate({ ...set, [field]: Math.max(0, set[field] + delta) });
  };

  const numberStyle = (active) => ({
    fontFamily: DISPLAY,
    fontSize: 34, fontWeight: 400,
    letterSpacing: -1.2,
    color: complete ? theme.ink2 : theme.ink,
    lineHeight: 1,
    fontFeatureSettings: '"tnum"',
    textDecoration: complete ? 'line-through' : 'none',
    textDecorationColor: theme.ink3,
    transition: 'all 0.2s',
  });

  return (
    <div style={{
      position: 'relative',
      background: theme.rowBg,
      borderRadius: rs(18),
      padding: rowPad,
      display: 'flex', alignItems: 'center', gap: 14,
      border: `1px solid ${theme.line}`,
      opacity: complete ? 0.7 : 1,
      transition: 'opacity 0.3s',
    }}>
      {/* Index */}
      <div style={{
        width: 26, display: 'flex', flexDirection: 'column',
        alignItems: 'center', gap: 3,
      }}>
        <div style={{
          fontFamily: MONO, fontSize: 10, color: theme.ink3,
          letterSpacing: 0.6,
        }}>SET</div>
        <div style={{
          fontFamily: DISPLAY, fontSize: 22, color: theme.ink,
          fontWeight: 400, lineHeight: 1,
        }}>{index + 1}</div>
      </div>

      {/* Divider */}
      <div style={{ width: 1, height: 40, background: theme.line }} />

      {/* Weight */}
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 2 }}>
        <div style={{
          fontFamily: MONO, fontSize: 9.5, letterSpacing: 0.6,
          color: theme.ink3, textTransform: 'uppercase',
        }}>lb</div>
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 8 }}>
          <button
            onClick={() => bump('weight', -2.5)}
            style={iconBtn(theme)}
          >{Icon.minus(theme.ink2, 10)}</button>
          <div style={numberStyle(activeField === 'weight')}>{set.weight.toFixed(1)}</div>
          <button
            onClick={() => bump('weight', 2.5)}
            style={iconBtn(theme)}
          >{Icon.plus(theme.ink2, 10)}</button>
        </div>
      </div>

      {/* Divider */}
      <div style={{ width: 1, height: 40, background: theme.line }} />

      {/* Reps */}
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 2 }}>
        <div style={{
          fontFamily: MONO, fontSize: 9.5, letterSpacing: 0.6,
          color: theme.ink3, textTransform: 'uppercase',
        }}>reps</div>
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 8 }}>
          <button
            onClick={() => bump('reps', -1)}
            style={iconBtn(theme)}
          >{Icon.minus(theme.ink2, 10)}</button>
          <div style={numberStyle(activeField === 'reps')}>{set.reps}</div>
          <button
            onClick={() => bump('reps', 1)}
            style={iconBtn(theme)}
          >{Icon.plus(theme.ink2, 10)}</button>
        </div>
      </div>

      {/* Check */}
      <button
        onClick={onComplete}
        style={{
          width: 40, height: 40, borderRadius: rs(20), flexShrink: 0,
          border: 'none', cursor: 'pointer',
          background: complete ? accent.solid : 'transparent',
          boxShadow: complete ? 'none' : `inset 0 0 0 1.5px ${theme.line}`,
          transition: 'all 0.2s',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}
      >
        {complete && Icon.check(accent.ink)}
      </button>
    </div>
  );
}

function iconBtn(theme) {
  return {
    width: 22, height: 22, borderRadius: rs(11), border: 'none',
    background: theme.surface2, cursor: 'pointer',
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    padding: 0,
  };
}

// ─────────────────────────────────────────────────────────────
// Rest timer block — collapsed + active states
// ─────────────────────────────────────────────────────────────
function RestTimer({ theme, accent, active, onToggle }) {
  const [preset, setPreset] = useState(60);
  const [remaining, setRemaining] = useState(60);
  const [running, setRunning] = useState(false);
  const intervalRef = useRef(null);

  useEffect(() => {
    if (running && remaining > 0) {
      intervalRef.current = setInterval(() => {
        setRemaining((r) => {
          if (r <= 1) { setRunning(false); return 0; }
          return r - 1;
        });
      }, 1000);
      return () => clearInterval(intervalRef.current);
    }
  }, [running, remaining]);

  const setPresetValue = (s) => {
    setPreset(s); setRemaining(s); setRunning(false);
  };
  const progress = remaining / preset;

  return (
    <div style={{
      background: active ? accent.solid : theme.rowBg,
      color: active ? accent.ink : theme.ink,
      borderRadius: rs(24), padding: active ? 28 : 20,
      border: `1px solid ${active ? accent.solid : theme.line}`,
      transition: 'all 0.35s cubic-bezier(.2,.9,.3,1)',
      position: 'relative', overflow: 'hidden',
    }}>
      {/* Progress fill when active */}
      {active && (
        <div style={{
          position: 'absolute', inset: 0,
          background: `linear-gradient(90deg, rgba(0,0,0,0.08) ${progress * 100}%, transparent ${progress * 100}%)`,
          pointerEvents: 'none',
        }} />
      )}

      <div style={{
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        marginBottom: active ? 8 : 14, position: 'relative',
      }}>
        <div style={{
          fontFamily: MONO, fontSize: 10, letterSpacing: 1,
          textTransform: 'uppercase',
          color: active ? accent.ink : theme.ink3,
        }}>Rest Timer</div>
        <div style={{
          fontFamily: MONO, fontSize: 10, letterSpacing: 1,
          color: active ? accent.ink : theme.ink3, opacity: 0.6,
        }}>{active ? 'active' : 'ready'}</div>
      </div>

      <div style={{
        display: 'flex', alignItems: 'flex-end', gap: 6,
        marginBottom: 18, position: 'relative',
      }}>
        <div style={{
          fontFamily: DISPLAY, fontSize: active ? 96 : 72, fontWeight: 400,
          letterSpacing: -3, lineHeight: 0.9,
          fontFeatureSettings: '"tnum"',
        }}>{remaining}</div>
        <div style={{
          fontFamily: DISPLAY, fontSize: 28, fontWeight: 400,
          paddingBottom: active ? 10 : 6,
          opacity: 0.5,
        }}>s</div>
        <div style={{ flex: 1 }} />
        {/* Control buttons */}
        <div style={{ display: 'flex', gap: 8, paddingBottom: 6 }}>
          <button
            onClick={() => { setRunning(!running); onToggle && onToggle(!running); }}
            style={{
              width: 44, height: 44, borderRadius: rs(22), border: 'none',
              background: active ? 'rgba(0,0,0,0.15)' : theme.ink,
              color: active ? accent.ink : theme.bg,
              cursor: 'pointer',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}
          >{running ? Icon.pause(active ? accent.ink : theme.bg) : Icon.play(active ? accent.ink : theme.bg)}</button>
          <button
            onClick={() => { setRemaining(preset); setRunning(false); }}
            style={{
              width: 44, height: 44, borderRadius: rs(22), border: 'none',
              background: active ? 'rgba(0,0,0,0.1)' : theme.surface2,
              cursor: 'pointer',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}
          >{Icon.reset(active ? accent.ink : theme.ink2)}</button>
        </div>
      </div>

      <div style={{
        display: 'flex', gap: 6, position: 'relative',
      }}>
        {[30, 60, 90, 120, 180, 300].map((s) => {
          const selected = s === preset;
          return (
            <button
              key={s}
              onClick={() => setPresetValue(s)}
              style={{
                flex: 1, height: 34, borderRadius: rs(17), border: 'none',
                cursor: 'pointer',
                background: selected
                  ? (active ? 'rgba(0,0,0,0.2)' : theme.ink)
                  : (active ? 'rgba(0,0,0,0.06)' : theme.surface2),
                color: selected
                  ? (active ? accent.ink : theme.bg)
                  : (active ? accent.ink : theme.ink2),
                fontFamily: MONO, fontSize: 11, fontWeight: 500,
                letterSpacing: 0.3,
              }}
            >{s}s</button>
          );
        })}
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// History row
// ─────────────────────────────────────────────────────────────
function HistoryCard({ theme, accent }) {
  const sets = [
    { reps: 12, w: 32.50, vol: 390 },
    { reps: 7,  w: 35.00, vol: 245 },
    { reps: 5,  w: 35.00, vol: 175 },
  ];
  const max = Math.max(...sets.map(s => s.vol));
  return (
    <div style={{
      background: theme.rowBg, borderRadius: rs(24),
      padding: 20, border: `1px solid ${theme.line}`,
    }}>
      <div style={{
        display: 'flex', alignItems: 'baseline', justifyContent: 'space-between',
        marginBottom: 16, paddingBottom: 12,
        borderBottom: `1px solid ${theme.line}`,
      }}>
        <div>
          <div style={{
            fontFamily: MONO, fontSize: 10, letterSpacing: 1,
            textTransform: 'uppercase', color: theme.ink3,
          }}>Last session · 2 Mar</div>
          <div style={{
            fontFamily: DISPLAY, fontSize: 20, color: theme.ink,
            marginTop: 2, letterSpacing: -0.4,
          }}>One week ago</div>
        </div>
        <div style={{ textAlign: 'right' }}>
          <div style={{
            fontFamily: MONO, fontSize: 10, letterSpacing: 1,
            color: theme.ink3, textTransform: 'uppercase',
          }}>Total vol</div>
          <div style={{
            fontFamily: DISPLAY, fontSize: 22, color: accent.solid,
            fontFeatureSettings: '"tnum"',
          }}>810<span style={{ fontSize: 13, opacity: 0.6, marginLeft: 3 }}>lb</span></div>
        </div>
      </div>

      {sets.map((s, i) => (
        <div key={i} style={{
          display: 'grid',
          gridTemplateColumns: '20px 1fr 50px 60px',
          alignItems: 'center', gap: 12,
          padding: '8px 0',
        }}>
          <div style={{
            fontFamily: MONO, fontSize: 10, color: theme.ink3,
          }}>0{i+1}</div>
          <div style={{
            fontFamily: DISPLAY, fontSize: 16, color: theme.ink,
            fontFeatureSettings: '"tnum"',
          }}>{s.w.toFixed(2)} <span style={{ fontSize: 11, color: theme.ink3 }}>lb</span> × {s.reps}</div>
          {/* Mini bar */}
          <div style={{
            height: 4, background: theme.surface2, borderRadius: rs(2),
            overflow: 'hidden', position: 'relative',
          }}>
            <div style={{
              position: 'absolute', inset: 0, width: `${(s.vol/max)*100}%`,
              background: accent.solid, borderRadius: rs(2),
            }} />
          </div>
          <div style={{
            fontFamily: MONO, fontSize: 12, color: theme.ink2,
            textAlign: 'right', fontFeatureSettings: '"tnum"',
          }}>{s.vol} lb</div>
        </div>
      ))}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Header with exercise title
// ─────────────────────────────────────────────────────────────
function Header({ theme, accent }) {
  return (
    <div style={{
      padding: '60px 20px 18px',
      display: 'flex', alignItems: 'center', gap: 12,
    }}>
      <button style={{
        width: 40, height: 40, borderRadius: rs(20), border: 'none',
        background: theme.surface2, cursor: 'pointer',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
      }}>{Icon.close(theme.ink2)}</button>

      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 0 }}>
        <div style={{
          fontFamily: MONO, fontSize: 10, letterSpacing: 1.2,
          textTransform: 'uppercase', color: theme.ink3,
        }}>Exercise · 04 of 06</div>
        <div style={{
          fontFamily: DISPLAY, fontSize: 28, fontWeight: 400,
          color: theme.ink, letterSpacing: -0.8, lineHeight: 1,
          marginTop: 2,
        }}>Military Press</div>
      </div>

      <button style={{
        width: 40, height: 40, borderRadius: rs(20),
        background: accent.solid, border: 'none', cursor: 'pointer',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
      }}>{Icon.check(accent.ink)}</button>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Notes field
// ─────────────────────────────────────────────────────────────
function Notes({ theme, accent }) {
  const [v, setV] = useState('');
  const [focus, setFocus] = useState(false);
  return (
    <div style={{
      background: theme.rowBg, borderRadius: rs(20),
      padding: 16, border: `1px solid ${focus ? accent.solid : theme.line}`,
      transition: 'border 0.2s',
    }}>
      <div style={{
        display: 'flex', alignItems: 'center', gap: 8,
        marginBottom: 8,
      }}>
        {Icon.note(theme.ink3)}
        <div style={{
          fontFamily: MONO, fontSize: 10, letterSpacing: 1,
          textTransform: 'uppercase', color: theme.ink3,
        }}>Notes</div>
        <div style={{ flex: 1 }} />
        <div style={{
          fontFamily: MONO, fontSize: 10,
          color: v.length > 0 ? theme.ink2 : theme.ink3,
        }}>{v.length}/140</div>
      </div>
      <textarea
        value={v}
        onChange={(e) => setV(e.target.value.slice(0, 140))}
        onFocus={() => setFocus(true)}
        onBlur={() => setFocus(false)}
        placeholder="How did that feel? Any form cues?"
        style={{
          width: '100%', minHeight: 50, resize: 'none', border: 'none',
          outline: 'none', background: 'transparent',
          fontFamily: DISPLAY, fontSize: 17, fontWeight: 400,
          color: theme.ink, letterSpacing: -0.2, lineHeight: 1.4,
          padding: 0,
        }}
      />
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Session add/remove set controls
// ─────────────────────────────────────────────────────────────
function SetControls({ theme, onAdd, onRemove }) {
  return (
    <div style={{ display: 'flex', gap: 8 }}>
      <button
        onClick={onRemove}
        style={{
          flex: 1, height: 44, borderRadius: rs(22), border: `1px dashed ${theme.line}`,
          background: 'transparent', cursor: 'pointer',
          display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
          color: theme.ink2, fontFamily: MONO, fontSize: 11, letterSpacing: 0.6,
          textTransform: 'uppercase',
        }}
      >{Icon.minus(theme.ink2)} Remove set</button>
      <button
        onClick={onAdd}
        style={{
          flex: 1, height: 44, borderRadius: rs(22), border: `1px dashed ${theme.line}`,
          background: 'transparent', cursor: 'pointer',
          display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
          color: theme.ink2, fontFamily: MONO, fontSize: 11, letterSpacing: 0.6,
          textTransform: 'uppercase',
        }}
      >{Icon.plus(theme.ink2)} Add set</button>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Main screen
// ─────────────────────────────────────────────────────────────
function WorkoutScreen({ tweaks, setTweaks }) {
  const theme = getTheme(tweaks.theme);
  const accent = ACCENTS[tweaks.accent] || ACCENTS.lime;

  const [sets, setSets] = useState([
    { weight: 32.5, reps: 12, complete: true },
    { weight: 35.0, reps: 7,  complete: true },
    { weight: 35.0, reps: 5,  complete: false },
  ]);

  const updateSet = (i, next) => {
    setSets(sets.map((s, idx) => idx === i ? next : s));
  };
  const completeSet = (i) => {
    setSets(sets.map((s, idx) => idx === i ? { ...s, complete: !s.complete } : s));
  };
  const addSet = () => setSets([...sets, { weight: sets[sets.length-1]?.weight || 30, reps: 5, complete: false }]);
  const removeSet = () => sets.length > 1 && setSets(sets.slice(0, -1));

  return (
    <div style={{
      width: '100%', minHeight: '100%',
      background: theme.bg, color: theme.ink,
      display: 'flex', flexDirection: 'column',
    }}>
      <Header theme={theme} accent={accent} />
      <StatsStrip theme={theme} accent={accent} />

      <div style={{
        display: 'flex', flexDirection: 'column', gap: 10,
        padding: '18px 16px 10px',
      }}>
        {sets.map((s, i) => (
          <SetRow
            key={i}
            set={s}
            index={i}
            onUpdate={(n) => updateSet(i, n)}
            onComplete={() => completeSet(i)}
            theme={theme}
            accent={accent}
            density={tweaks.density}
          />
        ))}
      </div>

      <div style={{ padding: '6px 16px 16px' }}>
        <SetControls theme={theme} onAdd={addSet} onRemove={removeSet} />
      </div>

      <div style={{ padding: '0 16px 16px' }}>
        <RestTimer theme={theme} accent={accent} active={tweaks.showTimer} />
      </div>

      <div style={{ padding: '0 16px 16px' }}>
        <Notes theme={theme} accent={accent} />
      </div>

      <div style={{ padding: '0 16px 60px' }}>
        <HistoryCard theme={theme} accent={accent} />
      </div>
    </div>
  );
}

Object.assign(window, {
  WorkoutScreen, ACCENTS, getTheme, TWEAK_DEFAULTS, DISPLAY, MONO, SANS, Icon,
  SetRow, iconBtn, rs,
});
