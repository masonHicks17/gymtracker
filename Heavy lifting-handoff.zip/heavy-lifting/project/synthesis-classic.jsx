// synthesis-classic.jsx — Synthesis layout (header ring + editorial timer + editorial history)
// but with the ORIGINAL stacked SetRow logging area instead of the tape scrubber.
// This is the "safe" version with reversible, atomic set-row interactions.

function WorkoutScreenSynthesisClassic({ tweaks }) {
  const theme = getTheme(tweaks.theme);
  const accent = ACCENTS[tweaks.accent] || ACCENTS.lime;

  const [sets, setSets] = React.useState([
    { weight: 75, reps: 12, complete: true },
    { weight: 80, reps: 7,  complete: true },
    { weight: 80, reps: 5,  complete: false },
  ]);

  // Editorial timer state
  const [preset, setPreset] = React.useState(60);
  const [remaining, setRemaining] = React.useState(60);
  const [running, setRunning] = React.useState(tweaks.showTimer || false);
  React.useEffect(() => {
    if (!running) return;
    const id = setInterval(() => setRemaining(r => r > 0 ? r - 1 : 0), 1000);
    return () => clearInterval(id);
  }, [running]);
  const timerProgress = remaining / preset;

  const done = sets.filter(x => x.complete).length;
  const progress = done / sets.length;
  const circ = 2 * Math.PI * 22;
  const dashOff = circ * (1 - progress);

  const updateSet = (i, next) => setSets(sets.map((s, idx) => idx === i ? next : s));
  const completeSet = (i) => setSets(sets.map((s, idx) => idx === i ? { ...s, complete: !s.complete } : s));
  const addSet = () => setSets([...sets, { weight: sets[sets.length-1]?.weight || 75, reps: 5, complete: false }]);
  const removeSet = () => sets.length > 1 && setSets(sets.slice(0, -1));

  return (
    <div style={{
      width: '100%', minHeight: '100%', background: theme.bg, color: theme.ink,
      padding: '54px 16px 60px',
      display: 'flex', flexDirection: 'column', gap: 16,
    }}>
      {/* Header — with small ring (matches Synthesis) */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '0 4px' }}>
        <button style={{
          width: 40, height: 40, borderRadius: 20, border: 'none',
          background: theme.surface2, cursor: 'pointer',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>{Icon.close(theme.ink2)}</button>

        <div style={{ flex: 1, textAlign: 'center' }}>
          <div style={{
            fontFamily: MONO, fontSize: 10, letterSpacing: 1.2,
            color: theme.ink3, textTransform: 'uppercase',
          }}>Exercise 04 · 06</div>
          <div style={{
            fontFamily: DISPLAY, fontSize: 22, marginTop: 2,
            letterSpacing: -0.5, color: theme.ink,
          }}>Military Press</div>
        </div>

        {/* Small progress ring */}
        <div style={{ position: 'relative', width: 48, height: 48 }}>
          <svg width="48" height="48" viewBox="0 0 48 48" style={{ transform: 'rotate(-90deg)' }}>
            <circle cx="24" cy="24" r="22" fill="none" stroke={theme.line} strokeWidth="3"/>
            <circle cx="24" cy="24" r="22" fill="none" stroke={accent.solid} strokeWidth="3"
              strokeLinecap="round" strokeDasharray={circ} strokeDashoffset={dashOff}
              style={{ transition: 'stroke-dashoffset 0.5s cubic-bezier(.2,.9,.3,1)' }}/>
          </svg>
          <div style={{
            position: 'absolute', inset: 0,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontFamily: MONO, fontSize: 11, color: theme.ink, fontWeight: 600,
            fontFeatureSettings: '"tnum"',
          }}>{done}/{sets.length}</div>
        </div>
      </div>

      {/* ORIGINAL STACKED SET ROWS — one row per set, each with its own ± steppers + check */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
        {sets.map((s, i) => (
          <SetRow
            key={i}
            set={s}
            index={i}
            onUpdate={(n) => updateSet(i, n)}
            onComplete={() => completeSet(i)}
            theme={theme}
            accent={accent}
            density={tweaks.density}
          />
        ))}
      </div>

      {/* Add/remove set controls */}
      <div style={{ display: 'flex', gap: 8 }}>
        <button
          onClick={removeSet}
          style={{
            flex: 1, height: 44, borderRadius: 22,
            border: `1px dashed ${theme.line}`,
            background: 'transparent', cursor: 'pointer',
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
            color: theme.ink2, fontFamily: MONO, fontSize: 11,
            letterSpacing: 0.6, textTransform: 'uppercase',
          }}
        >{Icon.minus(theme.ink2)} Remove set</button>
        <button
          onClick={addSet}
          style={{
            flex: 1, height: 44, borderRadius: 22,
            border: `1px dashed ${theme.line}`,
            background: 'transparent', cursor: 'pointer',
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
            color: theme.ink2, fontFamily: MONO, fontSize: 11,
            letterSpacing: 0.6, textTransform: 'uppercase',
          }}
        >{Icon.plus(theme.ink2)} Add set</button>
      </div>

      {/* EDITORIAL TIMER — same as Synthesis */}
      <div style={{
        background: running ? accent.solid : theme.rowBg,
        color: running ? accent.ink : theme.ink,
        borderRadius: 24, padding: running ? 24 : 20,
        border: `1px solid ${running ? accent.solid : theme.line}`,
        transition: 'all 0.35s cubic-bezier(.2,.9,.3,1)',
        position: 'relative', overflow: 'hidden',
      }}>
        {running && (
          <div style={{
            position: 'absolute', inset: 0,
            background: `linear-gradient(90deg, rgba(0,0,0,0.08) ${timerProgress * 100}%, transparent ${timerProgress * 100}%)`,
            pointerEvents: 'none',
          }} />
        )}
        <div style={{
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          marginBottom: 10, position: 'relative',
        }}>
          <div style={{
            fontFamily: MONO, fontSize: 10, letterSpacing: 1,
            textTransform: 'uppercase',
            color: running ? accent.ink : theme.ink3,
          }}>Rest Timer</div>
          <div style={{
            fontFamily: MONO, fontSize: 10, letterSpacing: 1,
            color: running ? accent.ink : theme.ink3, opacity: 0.6,
          }}>{running ? 'active' : 'ready'}</div>
        </div>
        <div style={{
          display: 'flex', alignItems: 'flex-end', gap: 6,
          marginBottom: 16, position: 'relative',
        }}>
          <div style={{
            fontFamily: DISPLAY, fontSize: running ? 88 : 68, fontWeight: 400,
            letterSpacing: -3, lineHeight: 0.9,
            fontFeatureSettings: '"tnum"',
            transition: 'font-size 0.35s',
          }}>{remaining}</div>
          <div style={{
            fontFamily: DISPLAY, fontSize: 26, fontWeight: 400,
            paddingBottom: 6, opacity: 0.5,
          }}>s</div>
          <div style={{ flex: 1 }} />
          <div style={{ display: 'flex', gap: 8, paddingBottom: 4 }}>
            <button
              onClick={() => setRunning(!running)}
              style={{
                width: 44, height: 44, borderRadius: 22, border: 'none',
                background: running ? 'rgba(0,0,0,0.15)' : theme.ink,
                color: running ? accent.ink : theme.bg, cursor: 'pointer',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}
            >{running ? Icon.pause(running ? accent.ink : theme.bg) : Icon.play(theme.bg)}</button>
            <button
              onClick={() => { setRemaining(preset); setRunning(false); }}
              style={{
                width: 44, height: 44, borderRadius: 22, border: 'none',
                background: running ? 'rgba(0,0,0,0.1)' : theme.surface2,
                cursor: 'pointer',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}
            >{Icon.reset(running ? accent.ink : theme.ink2)}</button>
          </div>
        </div>
        <div style={{ display: 'flex', gap: 6, position: 'relative' }}>
          {[30, 60, 90, 120, 180, 300].map((sec) => {
            const selected = sec === preset;
            return (
              <button key={sec}
                onClick={() => { setPreset(sec); setRemaining(sec); setRunning(false); }}
                style={{
                  flex: 1, height: 34, borderRadius: 17, border: 'none',
                  cursor: 'pointer',
                  background: selected
                    ? (running ? 'rgba(0,0,0,0.2)' : theme.ink)
                    : (running ? 'rgba(0,0,0,0.06)' : theme.surface2),
                  color: selected
                    ? (running ? accent.ink : theme.bg)
                    : (running ? accent.ink : theme.ink2),
                  fontFamily: MONO, fontSize: 11, fontWeight: 500, letterSpacing: 0.3,
                }}
              >{sec}s</button>
            );
          })}
        </div>
      </div>

      {/* EDITORIAL-STYLE LAST SESSION — same as Synthesis */}
      <EditorialHistory theme={theme} accent={accent} />
    </div>
  );
}

Object.assign(window, { WorkoutScreenSynthesisClassic });
