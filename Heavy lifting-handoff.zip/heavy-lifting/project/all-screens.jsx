// all-screens.jsx — Heavy Lifting app pages in the Synthesis design system
// Uses tokens from app.jsx (ACCENTS, getTheme, DISPLAY, MONO, SANS, Icon)

// ─────────────────────────────────────────────────────────────
// Shared phone shell
// ─────────────────────────────────────────────────────────────
function Phone({ dark = true, accent, width = 360, height = 780, time = '8:42', children }) {
  return (
    <div className="phone-shadow" style={{
      width, height, borderRadius: rs(46),
      background: dark ? '#0A0A0A' : '#F4F2EE',
      position: 'relative', overflow: 'hidden',
      fontFamily: SANS,
    }}>
      {/* Dynamic island */}
      <div style={{
        position: 'absolute', top: 10, left: '50%', transform: 'translateX(-50%)',
        width: 112, height: 33, borderRadius: rs(22), background: '#000', zIndex: 50,
      }} />
      {/* Status bar */}
      <div style={{
        position: 'absolute', top: 0, left: 0, right: 0, zIndex: 40,
        padding: '18px 24px 0', display: 'flex', justifyContent: 'space-between',
        alignItems: 'center', pointerEvents: 'none',
      }}>
        <div style={{
          fontFamily: '-apple-system, system-ui', fontSize: 15, fontWeight: 600,
          color: dark ? '#fff' : '#000',
        }}>{time}</div>
        <div style={{ width: 112 }} />
        <div style={{ display: 'flex', gap: 5, alignItems: 'center' }}>
          <svg width="16" height="10" viewBox="0 0 19 12"><rect x="0" y="7.5" width="3.2" height="4.5" rx="0.7" fill={dark ? '#fff' : '#000'}/><rect x="4.8" y="5" width="3.2" height="7" rx="0.7" fill={dark ? '#fff' : '#000'}/><rect x="9.6" y="2.5" width="3.2" height="9.5" rx="0.7" fill={dark ? '#fff' : '#000'}/><rect x="14.4" y="0" width="3.2" height="12" rx="0.7" fill={dark ? '#fff' : '#000'}/></svg>
          <svg width="14" height="10" viewBox="0 0 17 12"><path d="M8.5 3.2C10.8 3.2 12.9 4.1 14.4 5.6L15.5 4.5C13.7 2.7 11.2 1.5 8.5 1.5C5.8 1.5 3.3 2.7 1.5 4.5L2.6 5.6C4.1 4.1 6.2 3.2 8.5 3.2Z" fill={dark ? '#fff' : '#000'}/><path d="M8.5 6.8C9.9 6.8 11.1 7.3 12 8.2L13.1 7.1C11.8 5.9 10.2 5.1 8.5 5.1C6.8 5.1 5.2 5.9 3.9 7.1L5 8.2C5.9 7.3 7.1 6.8 8.5 6.8Z" fill={dark ? '#fff' : '#000'}/><circle cx="8.5" cy="10.5" r="1.5" fill={dark ? '#fff' : '#000'}/></svg>
          <svg width="22" height="11" viewBox="0 0 27 13"><rect x="0.5" y="0.5" width="23" height="12" rx="3.5" stroke={dark ? '#fff' : '#000'} strokeOpacity="0.35" fill="none"/><rect x="2" y="2" width="20" height="9" rx="2" fill={dark ? '#fff' : '#000'}/><path d="M25 4.5V8.5C25.8 8.2 26.5 7.2 26.5 6.5C26.5 5.8 25.8 4.8 25 4.5Z" fill={dark ? '#fff' : '#000'} fillOpacity="0.4"/></svg>
        </div>
      </div>
      {/* Content */}
      <div style={{ position: 'absolute', inset: 0, overflow: 'hidden' }}>
        {children}
      </div>
      {/* Home indicator */}
      <div style={{
        position: 'absolute', bottom: 7, left: '50%', transform: 'translateX(-50%)',
        width: 124, height: 5, borderRadius: rs(3), zIndex: 60,
        background: dark ? 'rgba(255,255,255,0.7)' : 'rgba(0,0,0,0.25)',
      }} />
    </div>
  );
}

// Editorial page header — mono label + Fraunces title
function PageHeader({ theme, eyebrow, title, right, top = 58 }) {
  return (
    <div style={{
      padding: `${top}px 22px 14px`, display: 'flex',
      alignItems: 'flex-end', justifyContent: 'space-between', gap: 12,
    }}>
      <div style={{ flex: 1, minWidth: 0 }}>
        {eyebrow && (
          <div style={{
            fontFamily: MONO, fontSize: 10, letterSpacing: 1.4,
            color: theme.ink3, textTransform: 'uppercase', marginBottom: 4,
          }}>{eyebrow}</div>
        )}
        <div style={{
          fontFamily: DISPLAY, fontSize: 32, fontWeight: 400, color: theme.ink,
          letterSpacing: -1, lineHeight: 1,
        }}>{title}</div>
      </div>
      {right}
    </div>
  );
}

// Bottom nav — 4 tabs
function TabBar({ theme, accent, active }) {
  const tabs = [
    { id: 'home',     label: 'Home',     icon: (c) => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><path d="M3 10l9-7 9 7v11a1 1 0 0 1-1 1h-5v-7h-6v7H4a1 1 0 0 1-1-1z"/></svg> },
    { id: 'workout',  label: 'Workout',  icon: (c) => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="1.7" strokeLinecap="round"><rect x="2" y="10" width="2.5" height="4" rx="0.6" fill={c}/><rect x="4.5" y="7.5" width="2" height="9" rx="0.6" fill={c}/><rect x="17.5" y="7.5" width="2" height="9" rx="0.6" fill={c}/><rect x="19.5" y="10" width="2.5" height="4" rx="0.6" fill={c}/><rect x="6.5" y="11" width="11" height="2" rx="0.5" fill={c}/></svg> },
    { id: 'log',      label: 'Log',      icon: (c) => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><path d="M6 3h9l5 5v13a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1z"/><path d="M15 3v5h5"/><path d="M9 14h7M9 18h7M9 10h3"/></svg> },
    { id: 'progress', label: 'Progress', icon: (c) => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><path d="M3 18l5-5 4 3 7-8"/><path d="M16 8h3v3"/></svg> },
  ];
  return (
    <div style={{
      position: 'absolute', bottom: 0, left: 0, right: 0, zIndex: 30,
      background: theme.bg, borderTop: `1px solid ${theme.line}`,
      padding: '10px 12px 28px',
      display: 'flex', justifyContent: 'space-around',
    }}>
      {tabs.map(t => {
        const on = t.id === active;
        const c = on ? accent.solid : theme.ink3;
        return (
          <div key={t.id} style={{
            display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4,
            position: 'relative', minWidth: 58,
          }}>
            {t.icon(c)}
            <div style={{
              fontFamily: MONO, fontSize: 9, letterSpacing: 0.8, color: c,
              textTransform: 'uppercase',
            }}>{t.label}</div>
            {on && <div style={{
              position: 'absolute', top: -10, left: '50%', transform: 'translateX(-50%)',
              width: 24, height: 2, borderRadius: rs(1), background: accent.solid,
            }}/>}
          </div>
        );
      })}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Small primitives
// ─────────────────────────────────────────────────────────────
function Card({ theme, children, style }) {
  return (
    <div style={{
      background: theme.rowBg, border: `1px solid ${theme.line}`,
      borderRadius: rs(22), padding: 18, ...style,
    }}>{children}</div>
  );
}

function MonoLabel({ theme, children, color, style }) {
  return <div style={{
    fontFamily: MONO, fontSize: 10, letterSpacing: 1.2,
    textTransform: 'uppercase', color: color || theme.ink3, ...style,
  }}>{children}</div>;
}

function Chevron({ c, size = 14 }) {
  return <svg width={size} height={size} viewBox="0 0 14 14" fill="none">
    <path d="M5 3l4 4-4 4" stroke={c} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>;
}

// ─────────────────────────────────────────────────────────────
// SCREEN 1 — HOME
// ─────────────────────────────────────────────────────────────
function HomeScreen({ theme, accent }) {
  return (
    <div style={{ width: '100%', height: '100%', background: theme.bg, color: theme.ink, position: 'relative', overflow: 'hidden' }}>
      <div style={{ position: 'absolute', inset: '0 0 80px 0', overflowY: 'auto' }}>
        <PageHeader
          theme={theme}
          eyebrow="Tuesday · 8 Apr"
          title="Heavy"
          right={
            <button style={{
              width: 38, height: 38, borderRadius: rs(19), border: `1px solid ${theme.line}`,
              background: 'transparent', color: theme.ink2, cursor: 'pointer',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round">
                <circle cx="12" cy="12" r="3"/>
                <path d="M12 2v3M12 19v3M2 12h3M19 12h3M4.9 4.9l2.1 2.1M17 17l2.1 2.1M4.9 19.1l2.1-2.1M17 7l2.1-2.1"/>
              </svg>
            </button>
          }
        />

        <div style={{ padding: '0 18px', display: 'flex', flexDirection: 'column', gap: 12 }}>
          {/* STREAK + LEVEL — editorial dual card */}
          <Card theme={theme} style={{ padding: 0, overflow: 'hidden' }}>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr' }}>
              <div style={{ padding: '20px 18px', borderRight: `1px solid ${theme.line}` }}>
                <MonoLabel theme={theme}>Streak</MonoLabel>
                <div style={{ display: 'flex', alignItems: 'baseline', gap: 6, marginTop: 6 }}>
                  <div style={{
                    fontFamily: DISPLAY, fontSize: 54, fontWeight: 400,
                    lineHeight: 1, letterSpacing: -2, color: theme.ink,
                    fontFeatureSettings: '"tnum"',
                  }}>12</div>
                  <div style={{ fontFamily: MONO, fontSize: 10, color: theme.ink3, letterSpacing: 0.8 }}>days</div>
                </div>
                {/* 7-day streak dots */}
                <div style={{ display: 'flex', gap: 4, marginTop: 14 }}>
                  {[1,1,1,1,1,1,0].map((on,i) => (
                    <div key={i} style={{
                      flex: 1, height: 3, borderRadius: rs(1.5),
                      background: on ? accent.solid : theme.line,
                    }}/>
                  ))}
                </div>
              </div>
              <div style={{ padding: '20px 18px' }}>
                <MonoLabel theme={theme}>Level · {'14'}</MonoLabel>
                <div style={{ display: 'flex', alignItems: 'baseline', gap: 6, marginTop: 6 }}>
                  <div style={{
                    fontFamily: DISPLAY, fontSize: 54, fontWeight: 400,
                    lineHeight: 1, letterSpacing: -2, color: accent.solid,
                    fontFeatureSettings: '"tnum"',
                  }}>14</div>
                </div>
                {/* XP bar */}
                <div style={{ marginTop: 14 }}>
                  <div style={{ height: 3, borderRadius: rs(1.5), background: theme.line, position: 'relative', overflow: 'hidden' }}>
                    <div style={{
                      position: 'absolute', inset: 0, width: '68%',
                      background: accent.solid, borderRadius: rs(1.5),
                    }}/>
                  </div>
                  <div style={{
                    fontFamily: MONO, fontSize: 9, color: theme.ink3,
                    letterSpacing: 0.6, marginTop: 6, textTransform: 'uppercase',
                  }}>320 xp to 15</div>
                </div>
              </div>
            </div>
          </Card>

          {/* UP NEXT — hero call-to-action */}
          <div style={{
            background: `linear-gradient(135deg, ${accent.hue || accent.solid}22, ${accent.solid}10)`,
            border: `1px solid ${accent.solid}55`,
            borderRadius: rs(22), padding: 20,
            position: 'relative', overflow: 'hidden',
          }}>
            {/* Faint chart motif top-right */}
            <svg width="100" height="60" viewBox="0 0 100 60" style={{
              position: 'absolute', right: -8, top: -8, opacity: 0.15,
            }}>
              <path d="M0 50 L20 42 L40 45 L60 25 L80 28 L100 8" stroke={accent.solid} strokeWidth="1.5" fill="none"/>
            </svg>

            <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 10 }}>
              <div style={{ flex: 1 }}>
                <MonoLabel theme={theme} color={accent.solid}>Up next</MonoLabel>
                <div style={{
                  fontFamily: DISPLAY, fontSize: 30, fontWeight: 400,
                  color: theme.ink, letterSpacing: -1, lineHeight: 1.02,
                  marginTop: 6,
                }}>Push Day</div>
                <div style={{
                  fontFamily: SANS, fontSize: 13, color: theme.ink2,
                  marginTop: 4, lineHeight: 1.4,
                }}>Chest · Shoulders · Triceps</div>
                <div style={{ display: 'flex', gap: 14, marginTop: 14 }}>
                  {[
                    ['Exercises', '6'],
                    ['Est. time', '48m'],
                    ['Last', '5d ago'],
                  ].map(([l, v]) => (
                    <div key={l}>
                      <div style={{ fontFamily: MONO, fontSize: 9, color: theme.ink3, letterSpacing: 0.8, textTransform: 'uppercase' }}>{l}</div>
                      <div style={{ fontFamily: DISPLAY, fontSize: 18, color: theme.ink, letterSpacing: -0.4, marginTop: 2, fontFeatureSettings: '"tnum"' }}>{v}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
            <button style={{
              marginTop: 18, width: '100%', height: 46, borderRadius: rs(23),
              background: accent.solid, color: accent.ink, border: 'none',
              fontFamily: MONO, fontSize: 11, letterSpacing: 1.4,
              textTransform: 'uppercase', fontWeight: 600, cursor: 'pointer',
              display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
            }}>Start Workout <Chevron c={accent.ink}/></button>
          </div>

          {/* VOLUME — big number + filter pills */}
          <Card theme={theme}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
              <MonoLabel theme={theme}>Volume · this week</MonoLabel>
              <div style={{
                display: 'flex', gap: 2, padding: 2,
                background: theme.surface2, borderRadius: rs(8),
              }}>
                {['Week', 'All'].map((l, i) => (
                  <div key={l} style={{
                    padding: '3px 9px', borderRadius: rs(6),
                    fontFamily: MONO, fontSize: 9, letterSpacing: 0.6,
                    textTransform: 'uppercase', fontWeight: 600,
                    background: i === 0 ? theme.rowBg : 'transparent',
                    color: i === 0 ? theme.ink : theme.ink3,
                    boxShadow: i === 0 ? `0 1px 2px rgba(0,0,0,0.3)` : 'none',
                  }}>{l}</div>
                ))}
              </div>
            </div>

            <div style={{ display: 'flex', alignItems: 'baseline', gap: 6 }}>
              <div style={{
                fontFamily: DISPLAY, fontSize: 56, fontWeight: 400,
                color: theme.ink, letterSpacing: -2.4, lineHeight: 0.95,
                fontFeatureSettings: '"tnum"',
              }}>24.8<span style={{ color: accent.solid }}>K</span></div>
              <div style={{ fontFamily: MONO, fontSize: 11, color: theme.ink3, letterSpacing: 0.6, paddingBottom: 6 }}>lb</div>
            </div>
            <div style={{ fontFamily: MONO, fontSize: 10, color: theme.ink3, letterSpacing: 0.6, marginTop: 4 }}>
              48 sets · 12 exercises
            </div>

            {/* Mini bar chart */}
            <div style={{ display: 'flex', alignItems: 'flex-end', gap: 4, height: 34, marginTop: 14 }}>
              {[0.5, 0.8, 0.3, 0.9, 0.6, 1.0, 0.2].map((h, i) => (
                <div key={i} style={{
                  flex: 1, height: `${h * 100}%`,
                  background: h === 1.0 ? accent.solid : theme.ink3,
                  opacity: h === 1.0 ? 1 : 0.3,
                  borderRadius: rs(2),
                }}/>
              ))}
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 6 }}>
              {['M','T','W','T','F','S','S'].map((d, i) => (
                <div key={i} style={{
                  fontFamily: MONO, fontSize: 9, color: i === 5 ? accent.solid : theme.ink3,
                  letterSpacing: 0.4, width: 14, textAlign: 'center',
                }}>{d}</div>
              ))}
            </div>
          </Card>

          {/* LAST SESSION */}
          <Card theme={theme} style={{ padding: 0 }}>
            <div style={{ padding: '16px 18px 14px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <div style={{ flex: 1 }}>
                <MonoLabel theme={theme}>Last session · 3 Apr</MonoLabel>
                <div style={{
                  fontFamily: DISPLAY, fontSize: 22, fontWeight: 400,
                  color: theme.ink, letterSpacing: -0.5, marginTop: 4,
                }}>Pull Day</div>
                <div style={{
                  fontFamily: SANS, fontSize: 12, color: theme.ink2, marginTop: 3,
                }}>18 sets · 9.2K lb · 52 min</div>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                <div style={{ fontFamily: MONO, fontSize: 10, color: accent.solid, letterSpacing: 0.8, textTransform: 'uppercase' }}>View</div>
                <Chevron c={accent.solid}/>
              </div>
            </div>
          </Card>
        </div>

        <div style={{ height: 20 }}/>
      </div>

      <TabBar theme={theme} accent={accent} active="home" />
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// SCREEN 2 — WORKOUT SETUP
// ─────────────────────────────────────────────────────────────
function WorkoutSetupScreen({ theme, accent }) {
  const SESSIONS = [
    { id: 'push',     label: 'Push',      desc: 'Chest · Shoulders · Tri' },
    { id: 'pull',     label: 'Pull',      desc: 'Back · Biceps' },
    { id: 'legs',     label: 'Legs',      desc: 'Quads · Hams · Glutes' },
    { id: 'upper',    label: 'Upper',     desc: 'Full upper body' },
    { id: 'lower',    label: 'Lower',     desc: 'Full lower body' },
    { id: 'full',     label: 'Full Body', desc: 'Everything' },
  ];
  return (
    <div style={{ width: '100%', height: '100%', background: theme.bg, color: theme.ink, position: 'relative', overflow: 'hidden' }}>
      <div style={{ position: 'absolute', inset: '0 0 80px 0', overflowY: 'auto' }}>
        <PageHeader theme={theme} eyebrow="Tuesday · 8 Apr" title="New Workout" />

        <div style={{ padding: '0 18px', display: 'flex', flexDirection: 'column', gap: 22 }}>
          {/* Gym selector */}
          <section>
            <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: 10 }}>
              <MonoLabel theme={theme}>Gym</MonoLabel>
              <div style={{ fontFamily: MONO, fontSize: 10, color: accent.solid, letterSpacing: 0.8, textTransform: 'uppercase' }}>Manage</div>
            </div>
            <div style={{ display: 'flex', gap: 8, overflowX: 'auto' }}>
              {[
                { label: 'Any Gym', sub: null, active: false },
                { label: 'Anytime Fitness', sub: '24 eqp', active: true },
                { label: 'Home', sub: '6 eqp', active: false },
              ].map((g, i) => (
                <div key={i} style={{
                  flexShrink: 0, padding: '12px 16px', borderRadius: rs(16),
                  border: `1px solid ${g.active ? accent.solid + '88' : theme.line}`,
                  background: g.active ? `${accent.solid}18` : theme.rowBg,
                  display: 'flex', flexDirection: 'column', gap: 2, minWidth: 108,
                }}>
                  <div style={{
                    fontFamily: DISPLAY, fontSize: 15, letterSpacing: -0.2,
                    color: theme.ink,
                  }}>{g.label}</div>
                  {g.sub && <div style={{ fontFamily: MONO, fontSize: 9, color: theme.ink3, letterSpacing: 0.5, textTransform: 'uppercase' }}>{g.sub}</div>}
                </div>
              ))}
            </div>
          </section>

          {/* Session type grid */}
          <section>
            <MonoLabel theme={theme} style={{ marginBottom: 10 }}>Session type</MonoLabel>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
              {SESSIONS.map((s, i) => {
                const on = i === 0;
                return (
                  <div key={s.id} style={{
                    padding: '16px 14px', borderRadius: rs(18),
                    border: `1px solid ${on ? accent.solid + '88' : theme.line}`,
                    background: on ? `${accent.solid}15` : theme.rowBg,
                    display: 'flex', flexDirection: 'column', gap: 2,
                    position: 'relative',
                  }}>
                    <div style={{ fontFamily: MONO, fontSize: 9, color: on ? accent.solid : theme.ink3, letterSpacing: 1, textTransform: 'uppercase' }}>0{i+1}</div>
                    <div style={{
                      fontFamily: DISPLAY, fontSize: 22, fontWeight: 400,
                      color: theme.ink, letterSpacing: -0.6, lineHeight: 1,
                      marginTop: 4,
                    }}>{s.label}</div>
                    <div style={{
                      fontFamily: SANS, fontSize: 11, color: theme.ink2,
                      marginTop: 4, lineHeight: 1.3,
                    }}>{s.desc}</div>
                    {on && <div style={{
                      position: 'absolute', top: 12, right: 12,
                      width: 14, height: 14, borderRadius: rs(7),
                      background: accent.solid,
                      display: 'flex', alignItems: 'center', justifyContent: 'center',
                    }}>{Icon.check(accent.ink)}</div>}
                  </div>
                );
              })}
            </div>
          </section>

          {/* Generate button */}
          <button style={{
            width: '100%', height: 54, borderRadius: rs(27),
            background: accent.solid, color: accent.ink, border: 'none',
            fontFamily: DISPLAY, fontSize: 19, fontWeight: 400, letterSpacing: -0.3,
            cursor: 'pointer', marginTop: 4,
          }}>Generate Workout</button>
        </div>
        <div style={{ height: 20 }}/>
      </div>
      <TabBar theme={theme} accent={accent} active="workout" />
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// SCREEN 3 — WORKOUT PREVIEW (Ready)
// ─────────────────────────────────────────────────────────────
function WorkoutPreviewScreen({ theme, accent }) {
  const EXERCISES = [
    { name: 'Barbell Bench Press', sets: 4, reps: 8, weight: 155, key: true },
    { name: 'Incline Dumbbell Press', sets: 3, reps: 10, weight: 60 },
    { name: 'Cable Flye', sets: 3, reps: 12, weight: 30 },
    { name: 'Overhead Press', sets: 4, reps: 8, weight: 95 },
    { name: 'Lateral Raise', sets: 3, reps: 15, weight: 20 },
    { name: 'Tricep Pushdown', sets: 3, reps: 12, weight: 45 },
  ];
  return (
    <div style={{ width: '100%', height: '100%', background: theme.bg, color: theme.ink, position: 'relative', overflow: 'hidden' }}>
      <div style={{ position: 'absolute', inset: '0 0 80px 0', overflowY: 'auto' }}>
        <PageHeader
          theme={theme}
          eyebrow="Ready to lift"
          title="Push Day"
          right={<div style={{ fontFamily: MONO, fontSize: 10, color: theme.ink3, letterSpacing: 0.8, textTransform: 'uppercase' }}>Change</div>}
        />

        {/* Meta strip */}
        <div style={{ padding: '0 22px 14px', borderBottom: `1px solid ${theme.line}`, marginBottom: 14 }}>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)' }}>
            {[
              ['Exercises', '6'],
              ['Sets', '20'],
              ['Est.', '48m'],
              ['Target', '12K'],
            ].map(([l,v], i) => (
              <div key={l} style={{ borderLeft: i > 0 ? `1px solid ${theme.line}` : 'none', paddingLeft: i > 0 ? 10 : 0 }}>
                <div style={{ fontFamily: MONO, fontSize: 9, color: theme.ink3, letterSpacing: 0.8, textTransform: 'uppercase' }}>{l}</div>
                <div style={{ fontFamily: DISPLAY, fontSize: 20, color: theme.ink, letterSpacing: -0.4, marginTop: 2, fontFeatureSettings: '"tnum"' }}>{v}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Exercise list */}
        <div style={{ padding: '0 18px', display: 'flex', flexDirection: 'column', gap: 8 }}>
          {EXERCISES.map((ex, i) => (
            <div key={i} style={{
              background: theme.rowBg, border: `1px solid ${theme.line}`,
              borderRadius: rs(18), padding: '14px 16px',
              display: 'flex', alignItems: 'center', gap: 12,
            }}>
              <div style={{
                width: 26, textAlign: 'center',
                fontFamily: MONO, fontSize: 10, color: theme.ink3, letterSpacing: 0.6,
              }}>0{i+1}</div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{
                  fontFamily: DISPLAY, fontSize: 15, color: theme.ink,
                  letterSpacing: -0.2, lineHeight: 1.2,
                  whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis',
                }}>{ex.name}</div>
                <div style={{ fontFamily: MONO, fontSize: 10, color: theme.ink3, letterSpacing: 0.4, marginTop: 3 }}>
                  <span style={{ color: accent.solid }}>{ex.weight} LB</span> · {ex.reps} reps
                </div>
              </div>
              {/* Sets counter */}
              <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                <button style={{
                  width: 26, height: 26, borderRadius: rs(13), border: 'none',
                  background: theme.surface2, cursor: 'pointer',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                }}>{Icon.minus(theme.ink2, 10)}</button>
                <div style={{
                  fontFamily: DISPLAY, fontSize: 18, color: theme.ink,
                  minWidth: 24, textAlign: 'center', fontFeatureSettings: '"tnum"',
                }}>{ex.sets}<span style={{ fontSize: 11, color: theme.ink3 }}>×</span></div>
                <button style={{
                  width: 26, height: 26, borderRadius: rs(13), border: 'none',
                  background: theme.surface2, cursor: 'pointer',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                }}>{Icon.plus(theme.ink2, 10)}</button>
              </div>
              <button style={{
                width: 26, height: 26, borderRadius: rs(13), border: 'none',
                background: 'transparent', cursor: 'pointer', padding: 0,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}>{Icon.swap(theme.ink3)}</button>
            </div>
          ))}

          {/* Add exercise */}
          <button style={{
            background: 'transparent', border: `1px dashed ${theme.line}`,
            borderRadius: rs(18), padding: '14px 16px', cursor: 'pointer',
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
            color: theme.ink2, fontFamily: MONO, fontSize: 11, letterSpacing: 0.8,
            textTransform: 'uppercase',
          }}>
            {Icon.plus(theme.ink2, 14)} Add exercise
          </button>

          {/* Start button */}
          <button style={{
            marginTop: 8, width: '100%', height: 54, borderRadius: rs(27),
            background: accent.solid, color: accent.ink, border: 'none',
            fontFamily: DISPLAY, fontSize: 19, fontWeight: 400, letterSpacing: -0.3,
            cursor: 'pointer',
          }}>Start Workout</button>
        </div>
        <div style={{ height: 20 }}/>
      </div>
      <TabBar theme={theme} accent={accent} active="workout" />
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// SCREEN 4 — LOG (Session list)
// ─────────────────────────────────────────────────────────────
function LogScreen({ theme, accent }) {
  const MONTHS = [
    {
      label: 'April', year: '2025',
      sessions: [
        { date: '08', weekday: 'Tue', type: 'Push Day',  sets: 20, vol: '12.1K', dur: '54m' },
        { date: '06', weekday: 'Sun', type: 'Legs Day',  sets: 18, vol: '16.4K', dur: '68m', pr: true },
        { date: '03', weekday: 'Thu', type: 'Pull Day',  sets: 18, vol: '9.2K',  dur: '52m' },
      ],
    },
    {
      label: 'March', year: '2025',
      sessions: [
        { date: '31', weekday: 'Mon', type: 'Push Day',  sets: 20, vol: '11.8K', dur: '51m' },
        { date: '29', weekday: 'Sat', type: 'Full Body', sets: 16, vol: '14.1K', dur: '72m' },
        { date: '26', weekday: 'Wed', type: 'Legs Day',  sets: 18, vol: '15.9K', dur: '66m' },
      ],
    },
  ];
  return (
    <div style={{ width: '100%', height: '100%', background: theme.bg, color: theme.ink, position: 'relative', overflow: 'hidden' }}>
      <div style={{ position: 'absolute', inset: '0 0 80px 0', overflowY: 'auto' }}>
        <PageHeader theme={theme} eyebrow="All sessions" title="Log" right={
          <button style={{
            width: 38, height: 38, borderRadius: rs(19), border: `1px solid ${theme.line}`,
            background: 'transparent', color: theme.ink2, cursor: 'pointer',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/></svg>
          </button>
        } />

        {/* Totals strip */}
        <div style={{ padding: '0 22px 16px', display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', borderBottom: `1px solid ${theme.line}`, marginBottom: 16 }}>
          {[
            ['Sessions', '42'],
            ['Volume', '512K', 'lb'],
            ['Time', '38h'],
          ].map(([l, v, u], i) => (
            <div key={l} style={{ borderLeft: i > 0 ? `1px solid ${theme.line}` : 'none', paddingLeft: i > 0 ? 12 : 0 }}>
              <div style={{ fontFamily: MONO, fontSize: 9, color: theme.ink3, letterSpacing: 0.8, textTransform: 'uppercase' }}>{l}</div>
              <div style={{ fontFamily: DISPLAY, fontSize: 24, color: theme.ink, letterSpacing: -0.6, marginTop: 3, fontFeatureSettings: '"tnum"' }}>
                {v}{u && <span style={{ fontSize: 11, color: theme.ink3, marginLeft: 3 }}>{u}</span>}
              </div>
            </div>
          ))}
        </div>

        {/* Month groups */}
        <div style={{ padding: '0 18px', display: 'flex', flexDirection: 'column', gap: 20 }}>
          {MONTHS.map(m => (
            <div key={m.label}>
              <div style={{
                display: 'flex', alignItems: 'baseline', gap: 8, marginBottom: 10, padding: '0 4px',
              }}>
                <div style={{
                  fontFamily: DISPLAY, fontSize: 22, color: theme.ink,
                  letterSpacing: -0.5, fontStyle: 'italic', fontWeight: 400,
                }}>{m.label}</div>
                <div style={{ fontFamily: MONO, fontSize: 10, color: theme.ink3, letterSpacing: 0.8 }}>{m.year}</div>
                <div style={{ flex: 1 }}/>
                <div style={{ fontFamily: MONO, fontSize: 10, color: theme.ink3, letterSpacing: 0.6, textTransform: 'uppercase' }}>{m.sessions.length} sess.</div>
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                {m.sessions.map((s, i) => (
                  <div key={i} style={{
                    background: theme.rowBg, border: `1px solid ${theme.line}`,
                    borderRadius: rs(18), padding: '14px 16px',
                    display: 'flex', alignItems: 'center', gap: 14,
                  }}>
                    {/* Date block */}
                    <div style={{ textAlign: 'center', minWidth: 38 }}>
                      <div style={{
                        fontFamily: DISPLAY, fontSize: 24, fontWeight: 400,
                        color: theme.ink, lineHeight: 1, letterSpacing: -0.6,
                      }}>{s.date}</div>
                      <div style={{ fontFamily: MONO, fontSize: 9, color: theme.ink3, letterSpacing: 0.6, textTransform: 'uppercase', marginTop: 3 }}>{s.weekday}</div>
                    </div>
                    <div style={{ width: 1, height: 32, background: theme.line }}/>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{
                        fontFamily: DISPLAY, fontSize: 15, color: theme.ink,
                        letterSpacing: -0.2, display: 'flex', alignItems: 'center', gap: 6,
                      }}>{s.type}
                      {s.pr && <span style={{
                        fontFamily: MONO, fontSize: 8, color: accent.ink,
                        background: accent.solid, padding: '2px 5px', borderRadius: rs(4),
                        letterSpacing: 0.6, fontWeight: 700,
                      }}>PR</span>}
                      </div>
                      <div style={{ fontFamily: MONO, fontSize: 10, color: theme.ink3, letterSpacing: 0.5, marginTop: 3 }}>
                        {s.sets} sets · <span style={{ color: theme.ink2 }}>{s.vol} lb</span> · {s.dur}
                      </div>
                    </div>
                    <Chevron c={theme.ink3}/>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
        <div style={{ height: 20 }}/>
      </div>
      <TabBar theme={theme} accent={accent} active="log" />
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// SCREEN 5 — SESSION DETAIL
// ─────────────────────────────────────────────────────────────
function SessionDetailScreen({ theme, accent }) {
  const EX = [
    { name: 'Barbell Bench Press', sets: [[155, 8], [155, 8], [165, 6], [165, 6]] },
    { name: 'Incline DB Press',    sets: [[60, 10], [60, 10], [65, 8]] },
    { name: 'Cable Flye',          sets: [[30, 12], [30, 12], [35, 10]] },
  ];
  return (
    <div style={{ width: '100%', height: '100%', background: theme.bg, color: theme.ink, position: 'relative', overflow: 'hidden' }}>
      <div style={{ position: 'absolute', inset: '0 0 80px 0', overflowY: 'auto' }}>
        {/* Back header */}
        <div style={{ padding: '58px 18px 10px', display: 'flex', alignItems: 'center', gap: 10 }}>
          <button style={{
            width: 38, height: 38, borderRadius: rs(19), border: `1px solid ${theme.line}`,
            background: theme.rowBg, cursor: 'pointer',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>
            <svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M9 3L5 7l4 4" stroke={theme.ink} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/></svg>
          </button>
          <MonoLabel theme={theme}>Log · Session</MonoLabel>
        </div>

        <div style={{ padding: '6px 22px 18px' }}>
          <div style={{ fontFamily: MONO, fontSize: 10, color: accent.solid, letterSpacing: 1, textTransform: 'uppercase', marginBottom: 4 }}>Sun · 6 Apr · 68m</div>
          <div style={{ fontFamily: DISPLAY, fontSize: 36, color: theme.ink, letterSpacing: -1.2, lineHeight: 1 }}>Legs Day</div>
        </div>

        {/* Totals */}
        <div style={{ padding: '0 22px 18px', borderBottom: `1px solid ${theme.line}`, marginBottom: 16 }}>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)' }}>
            {[
              ['Volume', '16.4', 'K lb'],
              ['Sets', '18'],
              ['PRs', '1', '★', true],
              ['Ease', '92%'],
            ].map(([l, v, u, pr], i) => (
              <div key={l} style={{ borderLeft: i > 0 ? `1px solid ${theme.line}` : 'none', paddingLeft: i > 0 ? 10 : 0 }}>
                <div style={{ fontFamily: MONO, fontSize: 9, color: theme.ink3, letterSpacing: 0.8, textTransform: 'uppercase' }}>{l}</div>
                <div style={{ fontFamily: DISPLAY, fontSize: 20, color: pr ? accent.solid : theme.ink, letterSpacing: -0.4, marginTop: 2, fontFeatureSettings: '"tnum"' }}>
                  {v}{u && <span style={{ fontSize: 10, color: theme.ink3, marginLeft: 2 }}>{u}</span>}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Exercise breakdowns */}
        <div style={{ padding: '0 18px', display: 'flex', flexDirection: 'column', gap: 14 }}>
          {EX.map((ex, exI) => {
            const total = ex.sets.reduce((s, [w,r]) => s + w * r, 0);
            const maxW = Math.max(...ex.sets.map(s => s[0]));
            return (
              <Card key={ex.name} theme={theme} style={{ padding: 0 }}>
                <div style={{
                  padding: '14px 18px', display: 'flex', alignItems: 'baseline', justifyContent: 'space-between',
                  borderBottom: `1px solid ${theme.line}`,
                }}>
                  <div>
                    <div style={{ fontFamily: MONO, fontSize: 9, color: theme.ink3, letterSpacing: 0.8, textTransform: 'uppercase' }}>0{exI+1} · {ex.sets.length} sets</div>
                    <div style={{ fontFamily: DISPLAY, fontSize: 18, color: theme.ink, letterSpacing: -0.3, marginTop: 2 }}>{ex.name}</div>
                  </div>
                  <div style={{ textAlign: 'right' }}>
                    <div style={{ fontFamily: MONO, fontSize: 9, color: theme.ink3, letterSpacing: 0.8, textTransform: 'uppercase' }}>Total</div>
                    <div style={{ fontFamily: DISPLAY, fontSize: 18, color: accent.solid, letterSpacing: -0.3, fontFeatureSettings: '"tnum"' }}>
                      {total.toLocaleString()}<span style={{ fontSize: 10, color: theme.ink3, marginLeft: 2 }}>lb</span>
                    </div>
                  </div>
                </div>
                {/* Set rows with bars */}
                <div style={{ padding: '10px 18px 14px' }}>
                  {ex.sets.map(([w, r], i) => (
                    <div key={i} style={{
                      display: 'grid', gridTemplateColumns: '22px 1fr 60px 50px',
                      alignItems: 'center', gap: 10,
                      padding: '6px 0',
                    }}>
                      <div style={{ fontFamily: MONO, fontSize: 10, color: theme.ink3 }}>0{i+1}</div>
                      <div style={{ height: 4, background: theme.surface2, borderRadius: rs(2), overflow: 'hidden' }}>
                        <div style={{
                          height: '100%', width: `${(w / maxW) * 100}%`,
                          background: accent.solid, borderRadius: rs(2),
                        }}/>
                      </div>
                      <div style={{ fontFamily: DISPLAY, fontSize: 14, color: theme.ink, textAlign: 'right', fontFeatureSettings: '"tnum"' }}>
                        {w}<span style={{ fontSize: 10, color: theme.ink3 }}> lb</span>
                      </div>
                      <div style={{ fontFamily: MONO, fontSize: 11, color: theme.ink2, textAlign: 'right' }}>×{r}</div>
                    </div>
                  ))}
                </div>
              </Card>
            );
          })}
        </div>
        <div style={{ height: 20 }}/>
      </div>
      <TabBar theme={theme} accent={accent} active="log" />
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// SCREEN 6 — PROGRESS
// ─────────────────────────────────────────────────────────────
function ProgressScreen({ theme, accent }) {
  // Sample lift history data (weeks)
  const points = [140, 145, 145, 150, 150, 155, 150, 155, 160, 160, 165];
  const minV = Math.min(...points) - 10;
  const maxV = Math.max(...points) + 5;
  const W = 292, H = 120, pad = 4;
  const pathD = points.map((v, i) => {
    const x = pad + (i / (points.length - 1)) * (W - pad * 2);
    const y = H - pad - ((v - minV) / (maxV - minV)) * (H - pad * 2);
    return `${i === 0 ? 'M' : 'L'}${x.toFixed(1)} ${y.toFixed(1)}`;
  }).join(' ');
  const areaD = pathD + ` L${(W - pad).toFixed(1)} ${H} L${pad} ${H} Z`;

  // Volume bars
  const vols = [8.2, 11.4, 9.8, 12.1, 14.2, 10.8, 13.5, 16.4, 11.8, 12.1];
  const maxVol = Math.max(...vols);

  return (
    <div style={{ width: '100%', height: '100%', background: theme.bg, color: theme.ink, position: 'relative', overflow: 'hidden' }}>
      <div style={{ position: 'absolute', inset: '0 0 80px 0', overflowY: 'auto' }}>
        <PageHeader theme={theme} eyebrow="Your lifts over time" title="Progress" />

        <div style={{ padding: '0 18px', display: 'flex', flexDirection: 'column', gap: 14 }}>
          {/* Lift chart card */}
          <Card theme={theme} style={{ padding: 0, overflow: 'hidden' }}>
            <div style={{ padding: '16px 18px 12px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <div>
                <MonoLabel theme={theme}>Top lift · Bench press</MonoLabel>
                <div style={{ display: 'flex', alignItems: 'baseline', gap: 6, marginTop: 6 }}>
                  <div style={{
                    fontFamily: DISPLAY, fontSize: 38, fontWeight: 400, color: theme.ink,
                    letterSpacing: -1.2, lineHeight: 0.95, fontFeatureSettings: '"tnum"',
                  }}>165</div>
                  <div style={{ fontFamily: MONO, fontSize: 11, color: theme.ink3, letterSpacing: 0.6 }}>lb</div>
                  <div style={{
                    fontFamily: MONO, fontSize: 10, color: accent.solid, letterSpacing: 0.8,
                    textTransform: 'uppercase', marginLeft: 6,
                  }}>+18% / 90d</div>
                </div>
              </div>
              <div style={{
                display: 'flex', gap: 2, padding: 2,
                background: theme.surface2, borderRadius: rs(8),
              }}>
                {['1M', '3M', 'All'].map((l, i) => (
                  <div key={l} style={{
                    padding: '4px 8px', borderRadius: rs(6),
                    fontFamily: MONO, fontSize: 9, letterSpacing: 0.6,
                    textTransform: 'uppercase', fontWeight: 600,
                    background: i === 1 ? theme.rowBg : 'transparent',
                    color: i === 1 ? theme.ink : theme.ink3,
                    boxShadow: i === 1 ? `0 1px 2px rgba(0,0,0,0.3)` : 'none',
                  }}>{l}</div>
                ))}
              </div>
            </div>

            {/* Line chart */}
            <div style={{ padding: '0 14px 14px' }}>
              <svg width="100%" height={H} viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none" style={{ display: 'block' }}>
                <defs>
                  <linearGradient id="liftGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0" stopColor={accent.solid} stopOpacity="0.35"/>
                    <stop offset="1" stopColor={accent.solid} stopOpacity="0"/>
                  </linearGradient>
                </defs>
                {/* horizontal gridlines */}
                {[0.25, 0.5, 0.75].map((t,i) => (
                  <line key={i} x1={pad} x2={W - pad} y1={H * t} y2={H * t} stroke={theme.line} strokeDasharray="2 4"/>
                ))}
                <path d={areaD} fill="url(#liftGrad)"/>
                <path d={pathD} stroke={accent.solid} strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round"/>
                {/* Final dot */}
                {(() => {
                  const x = W - pad;
                  const y = H - pad - ((points[points.length-1] - minV) / (maxV - minV)) * (H - pad * 2);
                  return <><circle cx={x} cy={y} r="6" fill={accent.solid} fillOpacity="0.25"/><circle cx={x} cy={y} r="3" fill={accent.solid}/></>;
                })()}
              </svg>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 4 }}>
                {['Jan','Feb','Mar','Apr'].map(m => (
                  <div key={m} style={{ fontFamily: MONO, fontSize: 9, color: theme.ink3, letterSpacing: 0.6 }}>{m}</div>
                ))}
              </div>
            </div>
          </Card>

          {/* Volume chart card */}
          <Card theme={theme} style={{ padding: '16px 18px' }}>
            <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: 12 }}>
              <MonoLabel theme={theme}>Volume · last 10 sessions</MonoLabel>
              <div style={{ fontFamily: DISPLAY, fontSize: 18, color: theme.ink, letterSpacing: -0.3, fontFeatureSettings: '"tnum"' }}>
                avg <span style={{ color: accent.solid }}>12.0K</span>
              </div>
            </div>
            <div style={{ display: 'flex', alignItems: 'flex-end', gap: 5, height: 90, marginBottom: 6 }}>
              {vols.map((v, i) => {
                const isMax = v === maxVol;
                return (
                  <div key={i} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4 }}>
                    <div style={{
                      fontFamily: MONO, fontSize: 8, color: isMax ? accent.solid : 'transparent', letterSpacing: 0.3,
                    }}>{v.toFixed(1)}</div>
                    <div style={{
                      width: '100%', height: `${(v / maxVol) * 75}px`,
                      background: isMax ? accent.solid : theme.ink3,
                      opacity: isMax ? 1 : 0.35,
                      borderRadius: rs(3),
                    }}/>
                  </div>
                );
              })}
            </div>
            <div style={{ height: 1, background: theme.line, marginTop: 4 }}/>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 6 }}>
              <div style={{ fontFamily: MONO, fontSize: 9, color: theme.ink3, letterSpacing: 0.5 }}>mar 12</div>
              <div style={{ fontFamily: MONO, fontSize: 9, color: theme.ink3, letterSpacing: 0.5 }}>apr 8</div>
            </div>
          </Card>

          {/* PR history */}
          <div>
            <div style={{ padding: '4px 4px 10px', display: 'flex', alignItems: 'baseline', justifyContent: 'space-between' }}>
              <MonoLabel theme={theme}>Personal records</MonoLabel>
              <div style={{ fontFamily: MONO, fontSize: 10, color: accent.solid, letterSpacing: 0.8, textTransform: 'uppercase' }}>8 total</div>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
              {[
                ['Barbell Squat',     '245', '6 Apr'],
                ['Deadlift',          '315', '29 Mar'],
                ['Bench Press',       '165', '8 Apr'],
                ['Overhead Press',    '115', '24 Mar'],
                ['Barbell Row',       '135', '17 Mar'],
              ].map(([n, w, d], i) => (
                <div key={n} style={{
                  background: theme.rowBg, border: `1px solid ${theme.line}`,
                  borderRadius: rs(14), padding: '12px 16px',
                  display: 'flex', alignItems: 'center', gap: 12,
                }}>
                  <div style={{ fontFamily: MONO, fontSize: 10, color: theme.ink3, letterSpacing: 0.6, minWidth: 18 }}>0{i+1}</div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontFamily: DISPLAY, fontSize: 15, color: theme.ink, letterSpacing: -0.2 }}>{n}</div>
                    <div style={{ fontFamily: MONO, fontSize: 9, color: theme.ink3, letterSpacing: 0.5, marginTop: 2, textTransform: 'uppercase' }}>{d}</div>
                  </div>
                  <div style={{ fontFamily: DISPLAY, fontSize: 22, color: accent.solid, letterSpacing: -0.4, fontFeatureSettings: '"tnum"' }}>
                    {w}<span style={{ fontSize: 10, color: theme.ink3, marginLeft: 2 }}>lb</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
        <div style={{ height: 20 }}/>
      </div>
      <TabBar theme={theme} accent={accent} active="progress" />
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// SCREEN 7 — POST-SESSION (Ease ratings)
// ─────────────────────────────────────────────────────────────
function PostSessionScreen({ theme, accent }) {
  const EX = [
    { name: 'Barbell Bench Press', rating: 'just' },
    { name: 'Incline DB Press',    rating: 'hard' },
    { name: 'Cable Flye',          rating: null },
    { name: 'Overhead Press',      rating: null },
  ];
  const ratings = [
    { id: 'easy', label: 'Easy',   sub: 'Level up', color: '#70D194' },
    { id: 'just', label: 'Solid',  sub: 'Hold',     color: accent.solid },
    { id: 'hard', label: 'Hard',   sub: 'Scale',    color: '#FF6B6B' },
  ];
  return (
    <div style={{ width: '100%', height: '100%', background: theme.bg, color: theme.ink, position: 'relative', overflow: 'hidden' }}>
      <div style={{ position: 'absolute', inset: 0, overflowY: 'auto' }}>
        <PageHeader theme={theme} eyebrow="Session complete" title="How'd it feel?" />

        {/* Summary strip */}
        <div style={{ padding: '0 22px 16px', borderBottom: `1px solid ${theme.line}`, marginBottom: 16 }}>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)' }}>
            {[
              ['Volume', '12.1', 'K lb'],
              ['Sets', '20'],
              ['Time', '54m'],
            ].map(([l,v,u], i) => (
              <div key={l} style={{ borderLeft: i > 0 ? `1px solid ${theme.line}` : 'none', paddingLeft: i > 0 ? 10 : 0 }}>
                <div style={{ fontFamily: MONO, fontSize: 9, color: theme.ink3, letterSpacing: 0.8, textTransform: 'uppercase' }}>{l}</div>
                <div style={{ fontFamily: DISPLAY, fontSize: 22, color: theme.ink, letterSpacing: -0.5, marginTop: 2, fontFeatureSettings: '"tnum"' }}>
                  {v}{u && <span style={{ fontSize: 10, color: theme.ink3, marginLeft: 2 }}>{u}</span>}
                </div>
              </div>
            ))}
          </div>
          <div style={{ marginTop: 12, padding: '10px 12px', background: `${accent.solid}15`, border: `1px solid ${accent.solid}40`, borderRadius: rs(12), display: 'flex', alignItems: 'center', gap: 10 }}>
            <div style={{
              width: 28, height: 28, borderRadius: rs(14), background: accent.solid,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontFamily: MONO, fontSize: 10, color: accent.ink, fontWeight: 700, letterSpacing: 0.5,
            }}>+85</div>
            <div style={{ flex: 1 }}>
              <div style={{ fontFamily: DISPLAY, fontSize: 14, color: theme.ink, letterSpacing: -0.2 }}>+85 XP earned</div>
              <div style={{ fontFamily: MONO, fontSize: 10, color: theme.ink3, letterSpacing: 0.5, marginTop: 2, textTransform: 'uppercase' }}>1 new PR · bench press</div>
            </div>
          </div>
        </div>

        {/* Ease ratings */}
        <div style={{ padding: '0 18px', display: 'flex', flexDirection: 'column', gap: 8 }}>
          <MonoLabel theme={theme} style={{ padding: '0 4px', marginBottom: 4 }}>Rate each lift</MonoLabel>
          {EX.map((ex, i) => (
            <Card key={ex.name} theme={theme} style={{ padding: '14px 16px' }}>
              <div style={{ fontFamily: DISPLAY, fontSize: 15, color: theme.ink, letterSpacing: -0.2, marginBottom: 10 }}>{ex.name}</div>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 6 }}>
                {ratings.map(r => {
                  const on = ex.rating === r.id;
                  return (
                    <div key={r.id} style={{
                      padding: '8px 0', borderRadius: rs(10),
                      border: `1px solid ${on ? r.color + '88' : theme.line}`,
                      background: on ? r.color + '20' : 'transparent',
                      textAlign: 'center',
                    }}>
                      <div style={{ fontFamily: DISPLAY, fontSize: 13, color: on ? r.color : theme.ink, letterSpacing: -0.2 }}>{r.label}</div>
                      <div style={{ fontFamily: MONO, fontSize: 8, color: theme.ink3, letterSpacing: 0.5, marginTop: 2, textTransform: 'uppercase' }}>{r.sub}</div>
                    </div>
                  );
                })}
              </div>
            </Card>
          ))}

          <button style={{
            marginTop: 10, width: '100%', height: 54, borderRadius: rs(27),
            background: accent.solid, color: accent.ink, border: 'none',
            fontFamily: DISPLAY, fontSize: 19, fontWeight: 400, letterSpacing: -0.3,
            cursor: 'pointer',
          }}>Save Session</button>
          <button style={{
            background: 'transparent', border: 'none', padding: '10px 0',
            fontFamily: MONO, fontSize: 11, letterSpacing: 1, color: theme.ink3,
            textTransform: 'uppercase', cursor: 'pointer',
          }}>Skip ratings</button>
          <div style={{ height: 20 }}/>
        </div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// SCREEN 8 — COMPLETE (summary)
// ─────────────────────────────────────────────────────────────
function CompleteScreen({ theme, accent }) {
  return (
    <div style={{ width: '100%', height: '100%', background: theme.bg, color: theme.ink, position: 'relative', overflow: 'hidden' }}>
      {/* Soft accent glow */}
      <div style={{
        position: 'absolute', top: -80, left: -40, right: -40, height: 400,
        background: `radial-gradient(ellipse at 50% 50%, ${accent.solid}22, transparent 65%)`,
        pointerEvents: 'none',
      }}/>

      <div style={{ position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column' }}>
        <div style={{ padding: '68px 26px 0' }}>
          <MonoLabel theme={theme} color={accent.solid}>Session saved</MonoLabel>
        </div>

        {/* Hero */}
        <div style={{ padding: '40px 26px 0', textAlign: 'left' }}>
          <div style={{
            fontFamily: DISPLAY, fontSize: 80, fontWeight: 400, color: theme.ink,
            letterSpacing: -3.5, lineHeight: 0.92, fontStyle: 'italic',
          }}>Well<br/>played.</div>
          <div style={{ fontFamily: SANS, fontSize: 14, color: theme.ink2, marginTop: 18, lineHeight: 1.5, maxWidth: 260 }}>
            Push day · 12,100 lb moved across 20 sets in 54 minutes. One new personal record.
          </div>
        </div>

        {/* XP ring + stats */}
        <div style={{ padding: '32px 26px 0', display: 'flex', alignItems: 'center', gap: 20 }}>
          <div style={{ position: 'relative', width: 88, height: 88, flexShrink: 0 }}>
            <svg width="88" height="88" viewBox="0 0 88 88" style={{ transform: 'rotate(-90deg)' }}>
              <circle cx="44" cy="44" r="38" stroke={theme.line} strokeWidth="4" fill="none"/>
              <circle cx="44" cy="44" r="38" stroke={accent.solid} strokeWidth="4" fill="none"
                strokeDasharray={`${2 * Math.PI * 38 * 0.68} ${2 * Math.PI * 38}`}
                strokeLinecap="round"/>
            </svg>
            <div style={{
              position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column',
              alignItems: 'center', justifyContent: 'center',
            }}>
              <div style={{ fontFamily: DISPLAY, fontSize: 24, color: theme.ink, letterSpacing: -0.8, lineHeight: 1 }}>+85</div>
              <div style={{ fontFamily: MONO, fontSize: 8, color: theme.ink3, letterSpacing: 0.8, marginTop: 2 }}>XP</div>
            </div>
          </div>
          <div style={{ flex: 1 }}>
            <MonoLabel theme={theme}>Level 14 · 68%</MonoLabel>
            <div style={{ fontFamily: DISPLAY, fontSize: 24, color: theme.ink, letterSpacing: -0.5, marginTop: 4 }}>320 XP to 15</div>
            <div style={{ fontFamily: SANS, fontSize: 12, color: theme.ink2, marginTop: 4 }}>~4 more sessions</div>
          </div>
        </div>

        <div style={{ flex: 1 }}/>

        {/* Actions */}
        <div style={{ padding: '0 22px 32px', display: 'flex', flexDirection: 'column', gap: 8 }}>
          <button style={{
            width: '100%', height: 54, borderRadius: rs(27),
            background: accent.solid, color: accent.ink, border: 'none',
            fontFamily: DISPLAY, fontSize: 19, letterSpacing: -0.3, cursor: 'pointer',
          }}>Start Another</button>
          <button style={{
            width: '100%', height: 54, borderRadius: rs(27),
            background: 'transparent', border: `1px solid ${theme.line}`,
            color: theme.ink, fontFamily: DISPLAY, fontSize: 17, letterSpacing: -0.2, cursor: 'pointer',
          }}>View in Log</button>
        </div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// SCREEN 9 — SETTINGS
// ─────────────────────────────────────────────────────────────
function SettingsScreen({ theme, accent }) {
  const SECTIONS = [
    {
      label: 'Account',
      rows: [
        { l: 'Goal',          v: 'Build strength' },
        { l: 'Units',         v: 'Pounds · lb' },
        { l: 'Week starts',   v: 'Monday' },
      ],
    },
    {
      label: 'AI Coach',
      rows: [
        { l: 'Claude API key', v: 'sk-ant-•••lq42', accent: true },
        { l: 'Auto-generate',  v: 'On' },
      ],
    },
    {
      label: 'Appearance',
      rows: [
        { l: 'Theme',  v: 'Dark' },
        { l: 'Accent', v: 'Orange', swatch: accent.solid },
      ],
    },
    {
      label: 'Data',
      rows: [
        { l: 'Export data',   v: 'CSV · JSON' },
        { l: 'Clear history', v: '', danger: true },
      ],
    },
  ];
  return (
    <div style={{ width: '100%', height: '100%', background: theme.bg, color: theme.ink, position: 'relative', overflow: 'hidden' }}>
      <div style={{ position: 'absolute', inset: 0, overflowY: 'auto' }}>
        {/* Header with close */}
        <div style={{ padding: '58px 22px 10px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <MonoLabel theme={theme}>Settings</MonoLabel>
          <button style={{
            width: 32, height: 32, borderRadius: rs(16), border: `1px solid ${theme.line}`,
            background: 'transparent', cursor: 'pointer',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>{Icon.close(theme.ink2)}</button>
        </div>
        <div style={{ padding: '0 22px 20px' }}>
          <div style={{ fontFamily: DISPLAY, fontSize: 32, color: theme.ink, letterSpacing: -1, lineHeight: 1 }}>Preferences</div>
        </div>

        {/* Profile card */}
        <div style={{ padding: '0 18px 22px' }}>
          <Card theme={theme} style={{ padding: 0 }}>
            <div style={{ padding: '16px 18px', display: 'flex', alignItems: 'center', gap: 14 }}>
              <div style={{
                width: 52, height: 52, borderRadius: rs(26), background: `${accent.solid}25`,
                border: `1px solid ${accent.solid}55`,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontFamily: DISPLAY, fontSize: 20, color: accent.solid, letterSpacing: -0.5,
              }}>MH</div>
              <div style={{ flex: 1 }}>
                <div style={{ fontFamily: DISPLAY, fontSize: 17, color: theme.ink, letterSpacing: -0.3 }}>Mason</div>
                <div style={{ fontFamily: MONO, fontSize: 10, color: theme.ink3, letterSpacing: 0.6, marginTop: 2, textTransform: 'uppercase' }}>Level 14 · 42 sessions</div>
              </div>
              <Chevron c={theme.ink3}/>
            </div>
          </Card>
        </div>

        {/* Setting sections */}
        <div style={{ padding: '0 18px', display: 'flex', flexDirection: 'column', gap: 18 }}>
          {SECTIONS.map(sec => (
            <div key={sec.label}>
              <MonoLabel theme={theme} style={{ padding: '0 4px 8px' }}>{sec.label}</MonoLabel>
              <Card theme={theme} style={{ padding: 0 }}>
                {sec.rows.map((r, i) => (
                  <div key={r.l} style={{
                    padding: '14px 18px', display: 'flex', alignItems: 'center', gap: 10,
                    borderTop: i > 0 ? `1px solid ${theme.line}` : 'none',
                  }}>
                    <div style={{
                      fontFamily: SANS, fontSize: 14,
                      color: r.danger ? '#FF6B6B' : theme.ink,
                      flex: 1,
                    }}>{r.l}</div>
                    {r.swatch && <div style={{ width: 14, height: 14, borderRadius: rs(7), background: r.swatch, border: `1px solid ${theme.line}` }}/>}
                    {r.v && <div style={{
                      fontFamily: MONO, fontSize: 11, letterSpacing: 0.4,
                      color: r.accent ? accent.solid : theme.ink3,
                    }}>{r.v}</div>}
                    {!r.danger && <Chevron c={theme.ink3}/>}
                  </div>
                ))}
              </Card>
            </div>
          ))}

          <div style={{ textAlign: 'center', padding: '16px 0 28px' }}>
            <div style={{ fontFamily: MONO, fontSize: 10, color: theme.ink3, letterSpacing: 1.2, textTransform: 'uppercase' }}>Heavy · v0.3.1</div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// TWEAKS CONFIG
// ─────────────────────────────────────────────────────────────
// Accent defaults per preset — overridden live by the color picker.
const ACCENT_PRESETS = {
  orange: '#FF9E5E',
  lime:   '#C8F751',
  violet: '#B79BFF',
  coral:  '#FF7A6B',
  cyan:   '#6BD5F0',
  sand:   '#E6D4A8',
};

// Font pairings — each has a display (serif/display face) + sans (body face).
// Mono stays JetBrains across the board so numeric columns stay tabular.
const FONT_PAIRINGS = {
  synthesis: { // current editorial look
    label: 'Synthesis · Fraunces + Inter',
    display: "'Fraunces', 'Times New Roman', serif",
    sans:    "'Inter', -apple-system, system-ui, sans-serif",
    google:  'Fraunces:ital,opsz,wght@0,9..144,300..600;1,9..144,400|Inter:wght@300..700',
  },
  athletic: { // condensed display + utilitarian body
    label: 'Athletic · Archivo Black + DM Sans',
    display: "'Archivo Black', 'Impact', sans-serif",
    sans:    "'DM Sans', -apple-system, system-ui, sans-serif",
    google:  'Archivo+Black|DM+Sans:wght@300..700',
  },
  journal: { // bookish humanist
    label: 'Journal · Newsreader + Work Sans',
    display: "'Newsreader', 'Georgia', serif",
    sans:    "'Work Sans', -apple-system, system-ui, sans-serif",
    google:  'Newsreader:opsz,wght@6..72,300..600|Work+Sans:wght@300..700',
  },
  monolith: { // geometric-only, strong contrast
    label: 'Monolith · Space Grotesk',
    display: "'Space Grotesk', sans-serif",
    sans:    "'Space Grotesk', sans-serif",
    google:  'Space+Grotesk:wght@300..700',
  },
  editorial: { // high-contrast magazine
    label: 'Editorial · Playfair + Manrope',
    display: "'Playfair Display', 'Times New Roman', serif",
    sans:    "'Manrope', -apple-system, system-ui, sans-serif",
    google:  'Playfair+Display:ital,wght@0,400..700;1,400..700|Manrope:wght@300..700',
  },
  brutalist: { // industrial, all-caps friendly
    label: 'Brutalist · IBM Plex Mono + Plex Sans',
    display: "'IBM Plex Mono', monospace",
    sans:    "'IBM Plex Sans', -apple-system, system-ui, sans-serif",
    google:  'IBM+Plex+Mono:wght@400;500;600;700|IBM+Plex+Sans:wght@300..700',
  },
};

// Widget shape presets map to a CSS --radius-scale multiplier.
const SHAPE_PRESETS = {
  sharp:  { label: 'Sharp',   scale: 0.05 },   // near-zero — hard corners
  soft:   { label: 'Soft',    scale: 0.5 },    // 50%
  round:  { label: 'Round',   scale: 1 },      // default (current)
  pillow: { label: 'Pillow',  scale: 1.45 },   // exaggerated
};

// ── Derive a full accent object (solid + ink) from a hex color.
// Ink color flips based on luminance so text stays legible on the accent.
function accentFromHex(hex) {
  const h = hex.replace('#', '');
  const r = parseInt(h.slice(0,2), 16) / 255;
  const g = parseInt(h.slice(2,4), 16) / 255;
  const b = parseInt(h.slice(4,6), 16) / 255;
  // Relative luminance (sRGB)
  const lum = 0.2126*r + 0.7152*g + 0.0722*b;
  const ink = lum > 0.55 ? '#0E0E0E' : '#FFFFFF';
  return { solid: hex, hue: hex, ink };
}

// ── Google Fonts loader — swaps the <link> href when pairing changes.
function useGoogleFontPairing(pairingKey) {
  React.useEffect(() => {
    const p = FONT_PAIRINGS[pairingKey] || FONT_PAIRINGS.synthesis;
    const id = '__tweakable_fonts__';
    let link = document.getElementById(id);
    if (!link) {
      link = document.createElement('link');
      link.id = id;
      link.rel = 'stylesheet';
      document.head.appendChild(link);
    }
    // JetBrains Mono is always available from the static <link> in the HTML.
    link.href = `https://fonts.googleapis.com/css2?family=${p.google.replace(/\|/g, '&family=')}&display=swap`;
  }, [pairingKey]);
}

// ─────────────────────────────────────────────────────────────
// CANVAS COMPOSITION
// ─────────────────────────────────────────────────────────────
// Defaults read/written by the host's tweak persistence. Must stay valid JSON.
const ALL_SCREENS_TWEAKS = /*EDITMODE-BEGIN*/{
  "accent": "#FF9E5E",
  "fontPairing": "synthesis",
  "shape": "round"
}/*EDITMODE-END*/;

function AllScreensApp() {
  const [tweaks, setTweak] = useTweaks(ALL_SCREENS_TWEAKS);

  // Load the pairing's webfonts on mount + whenever pairing changes.
  useGoogleFontPairing(tweaks.fontPairing);

  const pairing = FONT_PAIRINGS[tweaks.fontPairing] || FONT_PAIRINGS.synthesis;
  const shape   = SHAPE_PRESETS[tweaks.shape] || SHAPE_PRESETS.round;
  const accent  = accentFromHex(tweaks.accent || '#FF9E5E');
  const theme   = getTheme('dark');

  // Root-level CSS vars drive fonts + radius scale for every descendant.
  const rootStyle = {
    '--app-display': pairing.display,
    '--app-sans':    pairing.sans,
    '--app-mono':    "'JetBrains Mono', 'SF Mono', ui-monospace, monospace",
    '--radius-scale': shape.scale,
  };

  const commonProps = { theme, accent };

  return (
    <div style={rootStyle}>
      <DesignCanvas bg="#0e0e0e" grid="rgba(255,255,255,0.035)">
        <DCSection id="primary" title="Primary tabs" subtitle="The four top-level destinations">
          <DCArtboard id="home" label="01 · Home" width={360} height={780}>
            <Phone><HomeScreen {...commonProps}/></Phone>
          </DCArtboard>
          <DCArtboard id="workout-setup" label="02 · Workout / Setup" width={360} height={780}>
            <Phone><WorkoutSetupScreen {...commonProps}/></Phone>
          </DCArtboard>
          <DCArtboard id="workout-preview" label="03 · Workout / Preview" width={360} height={780}>
            <Phone><WorkoutPreviewScreen {...commonProps}/></Phone>
          </DCArtboard>
          <DCArtboard id="log" label="04 · Log" width={360} height={780}>
            <Phone><LogScreen {...commonProps}/></Phone>
          </DCArtboard>
          <DCArtboard id="progress" label="05 · Progress" width={360} height={780}>
            <Phone><ProgressScreen {...commonProps}/></Phone>
          </DCArtboard>
        </DCSection>

        <DCSection id="states" title="Session flow & modals" subtitle="Post-session, completion, session drill-down, settings">
          <DCArtboard id="post" label="06 · Post-session" width={360} height={780}>
            <Phone><PostSessionScreen {...commonProps}/></Phone>
          </DCArtboard>
          <DCArtboard id="complete" label="07 · Complete" width={360} height={780}>
            <Phone><CompleteScreen {...commonProps}/></Phone>
          </DCArtboard>
          <DCArtboard id="detail" label="08 · Session detail" width={360} height={780}>
            <Phone><SessionDetailScreen {...commonProps}/></Phone>
          </DCArtboard>
          <DCArtboard id="settings" label="09 · Settings" width={360} height={780}>
            <Phone><SettingsScreen {...commonProps}/></Phone>
          </DCArtboard>
        </DCSection>
      </DesignCanvas>

      {/* Tweak controls surfaced through the host toolbar */}
      <TweaksPanel title="Tweaks">
        <TweakSection label="Theme">
          <TweakColor
            label="Accent"
            value={tweaks.accent}
            onChange={(v) => setTweak('accent', v)}
          />
          <TweakRow label="Presets">
            <div style={{ display: 'flex', gap: 6 }}>
              {Object.entries(ACCENT_PRESETS).map(([k, v]) => (
                <button key={k}
                  onClick={() => setTweak('accent', v)}
                  title={k}
                  style={{
                    flex: 1, height: 22, borderRadius: 5,
                    background: v, border: tweaks.accent?.toLowerCase() === v.toLowerCase()
                      ? '2px solid rgba(0,0,0,0.7)' : '0.5px solid rgba(0,0,0,0.15)',
                    cursor: 'pointer', padding: 0,
                  }}
                />
              ))}
            </div>
          </TweakRow>
        </TweakSection>

        <TweakSection label="Typography">
          <TweakSelect
            label="Font pairing"
            value={tweaks.fontPairing}
            options={Object.entries(FONT_PAIRINGS).map(([k, v]) => ({ value: k, label: v.label }))}
            onChange={(v) => setTweak('fontPairing', v)}
          />
        </TweakSection>

        <TweakSection label="Widget shape">
          <TweakRadio
            label="Corners"
            value={tweaks.shape}
            options={Object.entries(SHAPE_PRESETS).map(([k, v]) => ({ value: k, label: v.label }))}
            onChange={(v) => setTweak('shape', v)}
          />
        </TweakSection>
      </TweaksPanel>
    </div>
  );
}

const allRoot = ReactDOM.createRoot(document.getElementById('root'));
allRoot.render(<AllScreensApp />);
