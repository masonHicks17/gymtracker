// main.jsx — Composition, Tweaks panel, wire everything up

function PhoneFrame({ children, dark, label, title }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 14 }}>
      <div className="frame-label" style={{
        fontFamily: "'JetBrains Mono', monospace", fontSize: 10,
        letterSpacing: 1.3, textTransform: 'uppercase', opacity: 0.45,
      }}>{label}</div>
      <div className="frame-title" style={{
        fontFamily: "'Fraunces', serif", fontSize: 20, letterSpacing: -0.4,
      }}>{title}</div>
      <div className="phone-shadow" style={{
        width: 360, height: 780, borderRadius: 46,
        background: dark ? '#000' : '#F2F2F7',
        position: 'relative', overflow: 'hidden',
      }}>
        {/* Dynamic island */}
        <div style={{
          position: 'absolute', top: 10, left: '50%', transform: 'translateX(-50%)',
          width: 112, height: 33, borderRadius: 22, background: '#000', zIndex: 50,
        }} />
        {/* Status bar */}
        <div style={{
          position: 'absolute', top: 0, left: 0, right: 0, zIndex: 40,
          padding: '18px 24px 0', display: 'flex', justifyContent: 'space-between',
          alignItems: 'center', pointerEvents: 'none',
        }}>
          <div style={{
            fontFamily: '-apple-system, system-ui', fontSize: 15, fontWeight: 600,
            color: dark ? '#fff' : '#000',
          }}>15:45</div>
          <div style={{ width: 112 }} />
          <div style={{ display: 'flex', gap: 5, alignItems: 'center' }}>
            <svg width="16" height="10" viewBox="0 0 19 12"><rect x="0" y="7.5" width="3.2" height="4.5" rx="0.7" fill={dark ? '#fff' : '#000'}/><rect x="4.8" y="5" width="3.2" height="7" rx="0.7" fill={dark ? '#fff' : '#000'}/><rect x="9.6" y="2.5" width="3.2" height="9.5" rx="0.7" fill={dark ? '#fff' : '#000'}/><rect x="14.4" y="0" width="3.2" height="12" rx="0.7" fill={dark ? '#fff' : '#000'}/></svg>
            <svg width="14" height="10" viewBox="0 0 17 12"><path d="M8.5 3.2C10.8 3.2 12.9 4.1 14.4 5.6L15.5 4.5C13.7 2.7 11.2 1.5 8.5 1.5C5.8 1.5 3.3 2.7 1.5 4.5L2.6 5.6C4.1 4.1 6.2 3.2 8.5 3.2Z" fill={dark ? '#fff' : '#000'}/><path d="M8.5 6.8C9.9 6.8 11.1 7.3 12 8.2L13.1 7.1C11.8 5.9 10.2 5.1 8.5 5.1C6.8 5.1 5.2 5.9 3.9 7.1L5 8.2C5.9 7.3 7.1 6.8 8.5 6.8Z" fill={dark ? '#fff' : '#000'}/><circle cx="8.5" cy="10.5" r="1.5" fill={dark ? '#fff' : '#000'}/></svg>
            <svg width="22" height="11" viewBox="0 0 27 13"><rect x="0.5" y="0.5" width="23" height="12" rx="3.5" stroke={dark ? '#fff' : '#000'} strokeOpacity="0.35" fill="none"/><rect x="2" y="2" width="20" height="9" rx="2" fill={dark ? '#fff' : '#000'}/><path d="M25 4.5V8.5C25.8 8.2 26.5 7.2 26.5 6.5C26.5 5.8 25.8 4.8 25 4.5Z" fill={dark ? '#fff' : '#000'} fillOpacity="0.4"/></svg>
          </div>
        </div>
        {/* Content (scrollable) */}
        <div style={{
          position: 'absolute', inset: 0, overflow: 'auto',
          WebkitOverflowScrolling: 'touch',
        }}>
          {children}
        </div>
        {/* Home indicator */}
        <div style={{
          position: 'absolute', bottom: 7, left: '50%', transform: 'translateX(-50%)',
          width: 124, height: 5, borderRadius: 3, zIndex: 60,
          background: dark ? 'rgba(255,255,255,0.7)' : 'rgba(0,0,0,0.25)',
        }} />
      </div>
    </div>
  );
}

function TweaksPanel({ tweaks, setTweaks, visible }) {
  const setKey = (k, v) => {
    const next = { ...tweaks, [k]: v };
    setTweaks(next);
    try {
      window.parent.postMessage({ type: '__edit_mode_set_keys', edits: { [k]: v } }, '*');
    } catch (e) {}
  };

  const accents = Object.keys(ACCENTS);
  return (
    <div className={`tweaks ${visible ? 'show' : ''}`}>
      <div className="tweaks-title">Tweaks</div>

      <div className="tweak-row">
        <div className="tweak-label">Theme</div>
        <div className="tweak-options">
          {['dark', 'light'].map(v => (
            <button key={v} className={`tweak-btn ${tweaks.theme === v ? 'active' : ''}`}
              onClick={() => setKey('theme', v)}>{v}</button>
          ))}
        </div>
      </div>

      <div className="tweak-row">
        <div className="tweak-label">Accent</div>
        <div className="tweak-options" style={{ gap: 6 }}>
          {accents.map(a => (
            <button key={a}
              className={`swatch ${tweaks.accent === a ? 'active' : ''}`}
              style={{ background: ACCENTS[a].solid }}
              onClick={() => setKey('accent', a)}
              title={a}
            />
          ))}
        </div>
      </div>

      <div className="tweak-row">
        <div className="tweak-label">Featured variant</div>
        <div className="tweak-options">
          {[
            ['synthesis', 'Scrubber'],
            ['classic', 'Classic'],
          ].map(([v, l]) => (
            <button key={v} className={`tweak-btn ${tweaks.variant === v ? 'active' : ''}`}
              onClick={() => setKey('variant', v)}>{l}</button>
          ))}
        </div>
      </div>

      <div className="tweak-row">
        <div className="tweak-label">Density</div>
        <div className="tweak-options">
          {['compact', 'comfortable'].map(v => (
            <button key={v} className={`tweak-btn ${tweaks.density === v ? 'active' : ''}`}
              onClick={() => setKey('density', v)}>{v}</button>
          ))}
        </div>
      </div>

      <div className="tweak-row">
        <div className="tweak-label">Timer state</div>
        <div className="tweak-options">
          {[
            [false, 'Ready'],
            [true,  'Active'],
          ].map(([v, l]) => (
            <button key={l} className={`tweak-btn ${tweaks.showTimer === v ? 'active' : ''}`}
              onClick={() => setKey('showTimer', v)}>{l}</button>
          ))}
        </div>
      </div>
    </div>
  );
}

function variantComponent(name) {
  if (name === 'classic') return WorkoutScreenSynthesisClassic;
  return WorkoutScreenSynthesis;
}

function App() {
  const [tweaks, setTweaks] = React.useState(TWEAK_DEFAULTS);
  const [editMode, setEditMode] = React.useState(false);

  React.useEffect(() => {
    const handler = (e) => {
      if (!e.data || !e.data.type) return;
      if (e.data.type === '__activate_edit_mode') setEditMode(true);
      if (e.data.type === '__deactivate_edit_mode') setEditMode(false);
    };
    window.addEventListener('message', handler);
    try {
      window.parent.postMessage({ type: '__edit_mode_available' }, '*');
    } catch (e) {}
    return () => window.removeEventListener('message', handler);
  }, []);

  const dark = tweaks.theme === 'dark';

  const variantDefs = {
    synthesis: { label: '01', title: 'Synthesis — Scrubber', C: WorkoutScreenSynthesis },
    classic:   { label: '02', title: 'Synthesis — Classic',  C: WorkoutScreenSynthesisClassic },
  };

  const order = ['synthesis', 'classic'];

  return (
    <div className={`page ${dark ? 'dark' : ''}`}>
      <div className="topbar">
        <div className="brand">
          <div className="brand-mark">Heavy</div>
          <div className="brand-sub">Workout Logger · Redesign</div>
        </div>
        <div className="session">
          Military Press · Session 04/06
        </div>
      </div>

      {/* Featured frame, then two variations side by side */}
      <div className="frames">
        {order.map((v) => {
          const def = variantDefs[v];
          const C = def.C;
          return (
            <PhoneFrame key={v} dark={dark} label={def.label} title={def.title}>
              <C tweaks={tweaks} setTweaks={setTweaks} />
            </PhoneFrame>
          );
        })}
      </div>

      <TweaksPanel tweaks={tweaks} setTweaks={setTweaks} visible={editMode} />
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);
