// variants.jsx — alternate visual treatments
const { useState: useStateV, useEffect: useEffectV, useRef: useRefV } = React;

// ─────────────────────────────────────────────────────────────
// VARIANT B — SIMPLE. A clean, stripped-back list. No dividers,
// no heavy cards. Big hierarchical type, lots of breathing room.
// The philosophy: the set is the content, chrome disappears.
// ─────────────────────────────────────────────────────────────
function WorkoutScreenSimple({ tweaks }) {
  const theme = getTheme(tweaks.theme);
  const accent = ACCENTS[tweaks.accent] || ACCENTS.lime;

  const [sets, setSets] = useStateV([
    { weight: 75, reps: 12, complete: true },
    { weight: 80, reps: 7,  complete: true },
    { weight: 80, reps: 5,  complete: false },
  ]);

  const toggle = (i) => setSets(sets.map((s, idx) => idx === i ? { ...s, complete: !s.complete } : s));

  return (
    <div style={{
      width: '100%', minHeight: '100%', background: theme.bg, color: theme.ink,
      padding: '58px 24px 60px',
    }}>
      {/* Minimal header */}
      <div style={{
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        marginBottom: 28,
      }}>
        <button style={{
          background: 'transparent', border: 'none', cursor: 'pointer', padding: 0,
          color: theme.ink2, fontFamily: SANS, fontSize: 15, fontWeight: 500,
        }}>Close</button>
        <div style={{
          fontFamily: MONO, fontSize: 10, letterSpacing: 1.2,
          color: theme.ink3, textTransform: 'uppercase',
        }}>04 · 06</div>
        <button style={{
          background: 'transparent', border: 'none', cursor: 'pointer', padding: 0,
          color: accent.solid, fontFamily: SANS, fontSize: 15, fontWeight: 600,
        }}>Done</button>
      </div>

      {/* Hero title */}
      <div style={{ marginBottom: 32 }}>
        <div style={{
          fontFamily: DISPLAY, fontSize: 42, fontWeight: 400,
          letterSpacing: -1.5, lineHeight: 1, color: theme.ink,
        }}>Military<br/>Press</div>
      </div>

      {/* Inline stats — no card */}
      <div style={{
        display: 'flex', gap: 28, marginBottom: 38, paddingBottom: 24,
        borderBottom: `1px solid ${theme.line}`,
      }}>
        {[
          { l: 'PR', v: '155', u: 'lb' },
          { l: 'Avg 6', v: '71', u: 'lb' },
          { l: 'Today', v: '1,785', u: 'lb', hi: true },
        ].map((s, i) => (
          <div key={i}>
            <div style={{
              fontFamily: MONO, fontSize: 10, letterSpacing: 0.8,
              color: theme.ink3, textTransform: 'uppercase', marginBottom: 4,
            }}>{s.l}</div>
            <div style={{
              fontFamily: DISPLAY, fontSize: 22, fontWeight: 400,
              color: s.hi ? accent.solid : theme.ink,
              letterSpacing: -0.5, lineHeight: 1,
              fontFeatureSettings: '"tnum"',
            }}>{s.v}<span style={{ fontSize: 11, opacity: 0.5, marginLeft: 3 }}>{s.u}</span></div>
          </div>
        ))}
      </div>

      {/* Sets — no cards, just rows */}
      <div style={{ marginBottom: 32 }}>
        <div style={{
          fontFamily: MONO, fontSize: 10, letterSpacing: 1.2,
          color: theme.ink3, textTransform: 'uppercase', marginBottom: 16,
        }}>Sets</div>

        {sets.map((s, i) => (
          <div key={i}
            onClick={() => toggle(i)}
            style={{
              display: 'flex', alignItems: 'center', gap: 16,
              padding: '18px 0',
              borderBottom: i < sets.length - 1 ? `1px solid ${theme.line}` : 'none',
              cursor: 'pointer',
            }}
          >
            <div style={{
              fontFamily: MONO, fontSize: 12, color: theme.ink3,
              width: 20, fontFeatureSettings: '"tnum"',
            }}>0{i+1}</div>
            <div style={{
              flex: 1,
              fontFamily: DISPLAY, fontSize: 28, fontWeight: 400,
              letterSpacing: -0.6, color: s.complete ? theme.ink2 : theme.ink,
              textDecoration: s.complete ? 'line-through' : 'none',
              textDecorationColor: theme.ink3,
              fontFeatureSettings: '"tnum"',
            }}>
              {s.weight} <span style={{ fontSize: 14, color: theme.ink3 }}>lb</span>
              <span style={{ color: theme.ink3, margin: '0 10px' }}>·</span>
              {s.reps} <span style={{ fontSize: 14, color: theme.ink3 }}>reps</span>
            </div>
            <div style={{
              width: 24, height: 24, borderRadius: 12,
              background: s.complete ? accent.solid : 'transparent',
              boxShadow: s.complete ? 'none' : `inset 0 0 0 1.5px ${theme.line}`,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              flexShrink: 0,
            }}>{s.complete && Icon.check(accent.ink)}</div>
          </div>
        ))}

        {/* Add set — ghost link */}
        <button
          onClick={() => setSets([...sets, { weight: 80, reps: 5, complete: false }])}
          style={{
            marginTop: 12, padding: '14px 0',
            background: 'transparent', border: 'none', cursor: 'pointer',
            fontFamily: SANS, fontSize: 14, fontWeight: 500,
            color: accent.solid, letterSpacing: -0.2,
          }}
        >+ Add another set</button>
      </div>

      {/* Timer — one line */}
      <div style={{
        padding: '20px 0', marginBottom: 24,
        borderTop: `1px solid ${theme.line}`,
        borderBottom: `1px solid ${theme.line}`,
        display: 'flex', alignItems: 'center', gap: 14,
      }}>
        <div style={{ flex: 1 }}>
          <div style={{
            fontFamily: MONO, fontSize: 10, letterSpacing: 1,
            color: theme.ink3, textTransform: 'uppercase', marginBottom: 2,
          }}>Rest</div>
          <div style={{
            fontFamily: DISPLAY, fontSize: 28,
            color: tweaks.showTimer ? accent.solid : theme.ink,
            letterSpacing: -0.6, lineHeight: 1,
            fontFeatureSettings: '"tnum"',
          }}>60<span style={{ fontSize: 14, opacity: 0.5, marginLeft: 2 }}>s</span></div>
        </div>
        <button style={{
          width: 48, height: 48, borderRadius: 24,
          background: tweaks.showTimer ? accent.solid : theme.ink,
          color: tweaks.showTimer ? accent.ink : theme.bg,
          border: 'none', cursor: 'pointer',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>{tweaks.showTimer ? Icon.pause(accent.ink) : Icon.play(theme.bg)}</button>
      </div>

      {/* Notes — ghost */}
      <div style={{ marginBottom: 28 }}>
        <div style={{
          fontFamily: MONO, fontSize: 10, letterSpacing: 1.2,
          color: theme.ink3, textTransform: 'uppercase', marginBottom: 8,
        }}>Notes</div>
        <textarea
          placeholder="Add a note"
          style={{
            width: '100%', border: 'none', outline: 'none', resize: 'none',
            background: 'transparent',
            fontFamily: DISPLAY, fontSize: 18, fontWeight: 400,
            color: theme.ink, lineHeight: 1.4, minHeight: 40, padding: 0,
            letterSpacing: -0.2,
          }}
        />
      </div>

      {/* Prev session — one line */}
      <div style={{
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        padding: '16px 0', borderTop: `1px solid ${theme.line}`,
      }}>
        <div>
          <div style={{
            fontFamily: MONO, fontSize: 10, letterSpacing: 1,
            color: theme.ink3, textTransform: 'uppercase',
          }}>Last session</div>
          <div style={{
            fontFamily: DISPLAY, fontSize: 18, color: theme.ink,
            letterSpacing: -0.3, marginTop: 2,
          }}>1 week ago</div>
        </div>
        <div style={{
          fontFamily: DISPLAY, fontSize: 22, color: accent.solid,
          letterSpacing: -0.5,
          fontFeatureSettings: '"tnum"',
        }}>1,860<span style={{ fontSize: 12, opacity: 0.5, marginLeft: 3 }}>lb</span></div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// VARIANT C — Soft & focused. Big hero card for the current set.
// ─────────────────────────────────────────────────────────────
function WorkoutScreenFocus({ tweaks }) {
  const theme = getTheme(tweaks.theme);
  const accent = ACCENTS[tweaks.accent] || ACCENTS.lime;

  const [sets, setSets] = useStateV([
    { weight: 75, reps: 12, complete: true },
    { weight: 80, reps: 7,  complete: true },
    { weight: 80, reps: 5,  complete: false },
  ]);
  const [current, setCurrent] = useStateV(2);

  const s = sets[current];

  return (
    <div style={{
      width: '100%', minHeight: '100%', background: theme.bg, color: theme.ink,
      display: 'flex', flexDirection: 'column',
      padding: '54px 20px 60px', gap: 20,
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
        <button style={{
          width: 40, height: 40, borderRadius: 20, border: 'none',
          background: theme.surface2, cursor: 'pointer',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>{Icon.close(theme.ink2)}</button>
        <div style={{ flex: 1, textAlign: 'center' }}>
          <div style={{
            fontFamily: MONO, fontSize: 10, letterSpacing: 1.2,
            color: theme.ink3, textTransform: 'uppercase',
          }}>Exercise 04 · 06</div>
          <div style={{
            fontFamily: DISPLAY, fontSize: 20, marginTop: 2,
            letterSpacing: -0.3, color: theme.ink,
          }}>Military Press</div>
        </div>
        <button style={{
          width: 40, height: 40, borderRadius: 20, background: accent.solid,
          border: 'none', cursor: 'pointer',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>{Icon.check(accent.ink)}</button>
      </div>

      <div style={{ display: 'flex', justifyContent: 'center', gap: 8 }}>
        {sets.map((x, i) => (
          <button
            key={i}
            onClick={() => setCurrent(i)}
            style={{
              width: i === current ? 28 : 8, height: 8, borderRadius: 4,
              border: 'none', cursor: 'pointer', padding: 0,
              background: x.complete ? accent.solid : (i === current ? theme.ink : theme.surface2),
              transition: 'all 0.25s',
            }}
          />
        ))}
      </div>

      <div style={{
        background: theme.rowBg, borderRadius: 28, padding: '28px 24px',
        border: `1px solid ${theme.line}`,
        display: 'flex', flexDirection: 'column', gap: 16,
      }}>
        <div style={{
          display: 'flex', alignItems: 'baseline', justifyContent: 'space-between',
        }}>
          <div style={{
            fontFamily: MONO, fontSize: 10, letterSpacing: 1.2,
            color: theme.ink3, textTransform: 'uppercase',
          }}>Set {current + 1} of {sets.length}</div>
          <div style={{
            fontFamily: MONO, fontSize: 10, letterSpacing: 1.2,
            color: s.complete ? accent.solid : theme.ink3, textTransform: 'uppercase',
          }}>{s.complete ? '✓ Done' : 'In progress'}</div>
        </div>

        <div style={{
          display: 'flex', alignItems: 'baseline', justifyContent: 'center',
          gap: 20, padding: '8px 0 12px',
        }}>
          <div style={{ textAlign: 'center' }}>
            <div style={{
              fontFamily: DISPLAY, fontSize: 84, fontWeight: 400,
              color: theme.ink, lineHeight: 1, letterSpacing: -3,
              fontFeatureSettings: '"tnum"',
            }}>{s.weight}</div>
            <div style={{
              fontFamily: MONO, fontSize: 11, letterSpacing: 1.2,
              color: theme.ink3, textTransform: 'uppercase', marginTop: 4,
            }}>pounds</div>
          </div>
          <div style={{
            fontFamily: DISPLAY, fontSize: 40, color: theme.ink3,
            alignSelf: 'center',
          }}>×</div>
          <div style={{ textAlign: 'center' }}>
            <div style={{
              fontFamily: DISPLAY, fontSize: 84, fontWeight: 400,
              color: theme.ink, lineHeight: 1, letterSpacing: -3,
              fontFeatureSettings: '"tnum"',
            }}>{s.reps}</div>
            <div style={{
              fontFamily: MONO, fontSize: 11, letterSpacing: 1.2,
              color: theme.ink3, textTransform: 'uppercase', marginTop: 4,
            }}>reps</div>
          </div>
        </div>

        <div style={{ display: 'flex', gap: 10 }}>
          {[
            { label: 'Weight', field: 'weight', step: 5 },
            { label: 'Reps',   field: 'reps',   step: 1 },
          ].map(({ label, field, step }) => (
            <div key={field} style={{
              flex: 1,
              background: theme.surface2, borderRadius: 14,
              padding: 4,
              display: 'flex', alignItems: 'center', gap: 4,
            }}>
              <button onClick={() => {
                const n = [...sets];
                n[current] = { ...s, [field]: Math.max(0, s[field] - step) };
                setSets(n);
              }} style={miniBtn(theme)}>{Icon.minus(theme.ink)}</button>
              <div style={{
                flex: 1, textAlign: 'center',
                fontFamily: MONO, fontSize: 10, color: theme.ink2,
                letterSpacing: 0.8, textTransform: 'uppercase',
              }}>{label}</div>
              <button onClick={() => {
                const n = [...sets];
                n[current] = { ...s, [field]: s[field] + step };
                setSets(n);
              }} style={miniBtn(theme)}>{Icon.plus(theme.ink)}</button>
            </div>
          ))}
        </div>

        <button
          onClick={() => {
            const n = [...sets];
            n[current] = { ...s, complete: !s.complete };
            setSets(n);
            if (!s.complete && current < sets.length - 1) {
              setTimeout(() => setCurrent(current + 1), 200);
            }
          }}
          style={{
            height: 54, borderRadius: 27, border: 'none', cursor: 'pointer',
            background: s.complete ? theme.surface2 : accent.solid,
            color: s.complete ? theme.ink2 : accent.ink,
            fontFamily: SANS, fontSize: 15, fontWeight: 600,
            letterSpacing: -0.2,
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
          }}
        >
          {s.complete ? 'Mark incomplete' : 'Log this set'}
        </button>
      </div>

      <div style={{ display: 'flex', gap: 10 }}>
        {[
          { label: 'PR 1RM', value: '155 lb' },
          { label: 'Avg 6', value: '71 lb' },
          { label: 'Today', value: '1,785 lb', hi: true },
        ].map((c, i) => (
          <div key={i} style={{
            flex: 1, background: theme.rowBg, borderRadius: 14,
            padding: '10px 12px', border: `1px solid ${theme.line}`,
          }}>
            <div style={{
              fontFamily: MONO, fontSize: 9, letterSpacing: 1,
              color: theme.ink3, textTransform: 'uppercase',
            }}>{c.label}</div>
            <div style={{
              fontFamily: DISPLAY, fontSize: 18, color: c.hi ? accent.solid : theme.ink,
              marginTop: 2, letterSpacing: -0.3, lineHeight: 1,
              fontFeatureSettings: '"tnum"',
            }}>{c.value}</div>
          </div>
        ))}
      </div>

      <div style={{
        background: tweaks.showTimer ? accent.solid : theme.rowBg,
        color: tweaks.showTimer ? accent.ink : theme.ink,
        borderRadius: 20, padding: 18,
        border: `1px solid ${tweaks.showTimer ? accent.solid : theme.line}`,
        display: 'flex', alignItems: 'center', gap: 14,
      }}>
        <div style={{
          width: 56, height: 56, borderRadius: 28,
          background: tweaks.showTimer ? 'rgba(0,0,0,0.12)' : theme.surface2,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontFamily: DISPLAY, fontSize: 22, fontWeight: 500,
          fontFeatureSettings: '"tnum"', letterSpacing: -0.5,
        }}>60</div>
        <div style={{ flex: 1 }}>
          <div style={{
            fontFamily: MONO, fontSize: 10, letterSpacing: 1,
            textTransform: 'uppercase', opacity: 0.55,
          }}>Rest between sets</div>
          <div style={{
            fontFamily: DISPLAY, fontSize: 18, letterSpacing: -0.3,
            marginTop: 2,
          }}>{tweaks.showTimer ? 'Resting · 60s' : 'Start 60 second timer'}</div>
        </div>
        <button style={{
          width: 44, height: 44, borderRadius: 22, border: 'none',
          background: tweaks.showTimer ? 'rgba(0,0,0,0.15)' : theme.ink,
          color: tweaks.showTimer ? accent.ink : theme.bg,
          cursor: 'pointer',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>{Icon.play(tweaks.showTimer ? accent.ink : theme.bg)}</button>
      </div>
    </div>
  );
}

function miniBtn(theme) {
  return {
    width: 36, height: 36, borderRadius: 10, border: 'none',
    background: theme.rowBg, cursor: 'pointer',
    display: 'flex', alignItems: 'center', justifyContent: 'center',
  };
}

// ─────────────────────────────────────────────────────────────
// VARIANT D — RING. Everything orbits a big progress ring that
// fills as the session completes. Tactile, confident, game-ish.
// ─────────────────────────────────────────────────────────────
function WorkoutScreenRing({ tweaks }) {
  const theme = getTheme(tweaks.theme);
  const accent = ACCENTS[tweaks.accent] || ACCENTS.lime;

  const [sets, setSets] = useStateV([
    { weight: 75, reps: 12, complete: true },
    { weight: 80, reps: 7,  complete: true },
    { weight: 80, reps: 5,  complete: false },
  ]);

  const done = sets.filter(s => s.complete).length;
  const progress = done / sets.length;
  const circ = 2 * Math.PI * 86;
  const dashOffset = circ * (1 - progress);
  const totalVol = sets.filter(s => s.complete).reduce((a, s) => a + s.weight * s.reps, 0);

  const toggle = (i) => setSets(sets.map((s, idx) => idx === i ? { ...s, complete: !s.complete } : s));
  const bump = (i, field, delta) => setSets(sets.map((s, idx) =>
    idx === i ? { ...s, [field]: Math.max(0, s[field] + delta) } : s
  ));

  return (
    <div style={{
      width: '100%', minHeight: '100%', background: theme.bg, color: theme.ink,
      padding: '54px 20px 60px',
    }}>
      {/* Header */}
      <div style={{
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        marginBottom: 20,
      }}>
        <button style={{
          width: 40, height: 40, borderRadius: 20, border: 'none',
          background: theme.surface2, cursor: 'pointer',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>{Icon.close(theme.ink2)}</button>
        <div style={{
          fontFamily: MONO, fontSize: 10, letterSpacing: 1.2,
          color: theme.ink3, textTransform: 'uppercase',
        }}>04 · 06</div>
        <button style={{
          width: 40, height: 40, borderRadius: 20, background: accent.solid,
          border: 'none', cursor: 'pointer',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>{Icon.check(accent.ink)}</button>
      </div>

      {/* Ring with center content */}
      <div style={{
        position: 'relative', width: 220, height: 220,
        margin: '0 auto 20px',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
      }}>
        <svg width="220" height="220" viewBox="0 0 220 220" style={{
          position: 'absolute', inset: 0, transform: 'rotate(-90deg)',
        }}>
          <circle cx="110" cy="110" r="86" fill="none"
            stroke={theme.line} strokeWidth="14"/>
          <circle cx="110" cy="110" r="86" fill="none"
            stroke={accent.solid} strokeWidth="14" strokeLinecap="round"
            strokeDasharray={circ} strokeDashoffset={dashOffset}
            style={{ transition: 'stroke-dashoffset 0.5s cubic-bezier(.2,.9,.3,1)' }}/>
        </svg>
        <div style={{ textAlign: 'center', position: 'relative' }}>
          <div style={{
            fontFamily: MONO, fontSize: 9, letterSpacing: 1.4,
            color: theme.ink3, textTransform: 'uppercase',
          }}>Military Press</div>
          <div style={{
            fontFamily: DISPLAY, fontSize: 56, fontWeight: 400,
            color: theme.ink, letterSpacing: -2, lineHeight: 1, marginTop: 4,
            fontFeatureSettings: '"tnum"',
          }}>{done}<span style={{ fontSize: 24, opacity: 0.4 }}>/{sets.length}</span></div>
          <div style={{
            fontFamily: MONO, fontSize: 10, letterSpacing: 1, marginTop: 4,
            color: theme.ink3, textTransform: 'uppercase',
          }}>sets done</div>
        </div>
      </div>

      {/* Compact stats row */}
      <div style={{
        display: 'flex', justifyContent: 'space-around', gap: 8,
        marginBottom: 26, padding: '14px 0',
        borderTop: `1px solid ${theme.line}`,
        borderBottom: `1px solid ${theme.line}`,
      }}>
        {[
          { l: 'PR', v: '155', u: 'lb' },
          { l: 'Today', v: totalVol.toLocaleString(), u: 'lb', hi: true },
          { l: 'Avg W', v: '71', u: 'lb' },
        ].map((s, i) => (
          <div key={i} style={{ textAlign: 'center' }}>
            <div style={{
              fontFamily: MONO, fontSize: 9, letterSpacing: 1,
              color: theme.ink3, textTransform: 'uppercase',
            }}>{s.l}</div>
            <div style={{
              fontFamily: DISPLAY, fontSize: 22,
              color: s.hi ? accent.solid : theme.ink,
              letterSpacing: -0.5, lineHeight: 1, marginTop: 2,
              fontFeatureSettings: '"tnum"',
            }}>{s.v}<span style={{ fontSize: 11, opacity: 0.5, marginLeft: 2 }}>{s.u}</span></div>
          </div>
        ))}
      </div>

      {/* Sets — pill cards with inline steppers */}
      <div style={{
        display: 'flex', flexDirection: 'column', gap: 10, marginBottom: 20,
      }}>
        {sets.map((s, i) => (
          <div key={i} style={{
            background: s.complete ? theme.surface2 : theme.rowBg,
            borderRadius: 28, padding: '10px 12px',
            border: `1px solid ${theme.line}`,
            display: 'flex', alignItems: 'center', gap: 8,
            opacity: s.complete ? 0.6 : 1,
            transition: 'opacity 0.25s',
          }}>
            <div style={{
              width: 36, height: 36, borderRadius: 18,
              background: s.complete ? accent.solid : theme.surface2,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontFamily: DISPLAY, fontSize: 16,
              color: s.complete ? accent.ink : theme.ink,
              flexShrink: 0,
            }}>{i+1}</div>

            <div style={{ flex: 1, display: 'flex', alignItems: 'center', gap: 4 }}>
              <button onClick={() => bump(i, 'weight', -5)} style={pillStep(theme)}>{Icon.minus(theme.ink2)}</button>
              <div style={{
                flex: 1, textAlign: 'center',
                fontFamily: DISPLAY, fontSize: 18, color: theme.ink,
                fontFeatureSettings: '"tnum"', letterSpacing: -0.3,
                textDecoration: s.complete ? 'line-through' : 'none',
              }}>{s.weight}<span style={{ fontSize: 10, color: theme.ink3, marginLeft: 2 }}>lb</span></div>
              <button onClick={() => bump(i, 'weight', 5)} style={pillStep(theme)}>{Icon.plus(theme.ink2)}</button>
            </div>

            <div style={{ width: 1, height: 24, background: theme.line }} />

            <div style={{ flex: 0.7, display: 'flex', alignItems: 'center', gap: 4 }}>
              <button onClick={() => bump(i, 'reps', -1)} style={pillStep(theme)}>{Icon.minus(theme.ink2)}</button>
              <div style={{
                flex: 1, textAlign: 'center',
                fontFamily: DISPLAY, fontSize: 18, color: theme.ink,
                fontFeatureSettings: '"tnum"', letterSpacing: -0.3,
                textDecoration: s.complete ? 'line-through' : 'none',
              }}>{s.reps}<span style={{ fontSize: 10, color: theme.ink3, marginLeft: 2 }}>×</span></div>
              <button onClick={() => bump(i, 'reps', 1)} style={pillStep(theme)}>{Icon.plus(theme.ink2)}</button>
            </div>

            <button
              onClick={() => toggle(i)}
              style={{
                width: 36, height: 36, borderRadius: 18, border: 'none',
                background: s.complete ? accent.solid : 'transparent',
                boxShadow: s.complete ? 'none' : `inset 0 0 0 1.5px ${theme.line}`,
                cursor: 'pointer', flexShrink: 0,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}
            >{s.complete && Icon.check(accent.ink)}</button>
          </div>
        ))}

        <button
          onClick={() => setSets([...sets, { weight: 80, reps: 5, complete: false }])}
          style={{
            padding: '14px', borderRadius: 28,
            border: `1.5px dashed ${theme.line}`, background: 'transparent',
            cursor: 'pointer', color: theme.ink2,
            fontFamily: SANS, fontSize: 14, fontWeight: 500, letterSpacing: -0.2,
          }}
        >+ Add set</button>
      </div>

      {/* Timer — pill */}
      <div style={{
        background: tweaks.showTimer ? accent.solid : theme.rowBg,
        color: tweaks.showTimer ? accent.ink : theme.ink,
        borderRadius: 28, padding: '14px 16px',
        border: `1px solid ${tweaks.showTimer ? accent.solid : theme.line}`,
        display: 'flex', alignItems: 'center', gap: 12, marginBottom: 16,
      }}>
        <div style={{
          fontFamily: MONO, fontSize: 10, letterSpacing: 1,
          textTransform: 'uppercase', opacity: 0.55, flex: 1,
        }}>Rest timer</div>
        <div style={{
          fontFamily: DISPLAY, fontSize: 24, letterSpacing: -0.6,
          fontFeatureSettings: '"tnum"',
        }}>60s</div>
        <button style={{
          width: 40, height: 40, borderRadius: 20, border: 'none',
          background: tweaks.showTimer ? 'rgba(0,0,0,0.15)' : theme.ink,
          color: tweaks.showTimer ? accent.ink : theme.bg, cursor: 'pointer',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>{tweaks.showTimer ? Icon.pause(accent.ink) : Icon.play(theme.bg)}</button>
      </div>

      {/* Prev session ribbon */}
      <div style={{
        background: theme.rowBg, borderRadius: 20, padding: 16,
        border: `1px solid ${theme.line}`,
        display: 'flex', alignItems: 'center', gap: 12,
      }}>
        <div style={{
          width: 44, height: 44, borderRadius: 22,
          background: theme.surface2,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>{Icon.chart(accent.solid)}</div>
        <div style={{ flex: 1 }}>
          <div style={{
            fontFamily: MONO, fontSize: 10, letterSpacing: 1,
            color: theme.ink3, textTransform: 'uppercase',
          }}>Last · 1 wk ago</div>
          <div style={{
            fontFamily: DISPLAY, fontSize: 16, color: theme.ink,
            letterSpacing: -0.3, marginTop: 2,
          }}>75 × 12 · 80 × 7 · 80 × 5</div>
        </div>
        <div style={{
          fontFamily: DISPLAY, fontSize: 18, color: accent.solid,
          letterSpacing: -0.3,
          fontFeatureSettings: '"tnum"',
        }}>1,860<span style={{ fontSize: 10, opacity: 0.5, marginLeft: 2 }}>lb</span></div>
      </div>
    </div>
  );
}

function pillStep(theme) {
  return {
    width: 26, height: 26, borderRadius: 13, border: 'none',
    background: 'transparent', cursor: 'pointer',
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    padding: 0, flexShrink: 0,
  };
}

Object.assign(window, { WorkoutScreenSimple, WorkoutScreenFocus, WorkoutScreenRing });
