// synthesis.jsx — Innovative scrubber-scale UI with small ring + editorial history

function WorkoutScreenSynthesis({ tweaks }) {
  const theme = getTheme(tweaks.theme);
  const accent = ACCENTS[tweaks.accent] || ACCENTS.lime;

  const [sets, setSets] = React.useState([
    { weight: 75, reps: 12, complete: true },
    { weight: 80, reps: 7,  complete: true },
    { weight: 80, reps: 5,  complete: false },
  ]);
  const [current, setCurrent] = React.useState(2);
  const [activeDim, setActiveDim] = React.useState('weight'); // 'weight' | 'reps'
  const s = sets[current];

  // Editorial timer state
  const [preset, setPreset] = React.useState(60);
  const [remaining, setRemaining] = React.useState(60);
  const [running, setRunning] = React.useState(tweaks.showTimer || false);
  React.useEffect(() => {
    if (!running) return;
    const id = setInterval(() => setRemaining(r => r > 0 ? r - 1 : 0), 1000);
    return () => clearInterval(id);
  }, [running]);
  const timerProgress = remaining / preset;

  const totalVol = sets.filter(x => x.complete).reduce((a, x) => a + x.weight * x.reps, 0);
  const done = sets.filter(x => x.complete).length;
  const progress = done / sets.length;
  const circ = 2 * Math.PI * 22;
  const dashOff = circ * (1 - progress);

  const bump = (field, delta) => {
    const n = [...sets];
    n[current] = { ...s, [field]: Math.max(0, s[field] + delta) };
    setSets(n);
  };
  const toggleCurrent = () => {
    const n = [...sets];
    n[current] = { ...s, complete: !s.complete };
    setSets(n);
    if (!s.complete && current < sets.length - 1) {
      setTimeout(() => setCurrent(current + 1), 250);
    }
  };

  // TAPE SCALE — the innovative input. Renders a horizontal ruler centered on current value.
  const TapeScale = ({ value, step, range, unit, onChange }) => {
    const ticks = [];
    for (let i = -range; i <= range; i++) {
      ticks.push(value + i * step);
    }
    return (
      <div style={{
        position: 'relative', height: 80, overflow: 'hidden',
        borderRadius: 14, background: theme.surface2,
      }}>
        {/* Center indicator */}
        <div style={{
          position: 'absolute', left: '50%', top: 0, bottom: 0, width: 2,
          background: accent.solid, transform: 'translateX(-50%)', zIndex: 3,
          borderRadius: 1,
        }} />
        {/* Ticks */}
        <div style={{
          position: 'absolute', inset: 0, display: 'flex',
          alignItems: 'center', justifyContent: 'center', gap: 0,
        }}>
          {ticks.map((t, i) => {
            const dist = Math.abs(i - range);
            const isMajor = (t % (step * 5)) === 0;
            const h = isMajor ? 28 : 16;
            return (
              <div key={i} style={{
                width: 22, display: 'flex', flexDirection: 'column',
                alignItems: 'center', justifyContent: 'flex-end',
                height: '100%', paddingBottom: 14,
                opacity: 1 - dist * 0.15,
              }}>
                <div style={{
                  fontFamily: MONO, fontSize: 10, color: theme.ink2,
                  marginBottom: 4,
                  visibility: isMajor ? 'visible' : 'hidden',
                  fontFeatureSettings: '"tnum"',
                }}>{t}</div>
                <div style={{
                  width: 1.5, height: h,
                  background: isMajor ? theme.ink2 : theme.ink3,
                  borderRadius: 1,
                }}/>
              </div>
            );
          })}
        </div>
        {/* Drag hitbox */}
        <div
          onClick={(e) => {
            const rect = e.currentTarget.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const center = rect.width / 2;
            const delta = Math.round((x - center) / 22) * step;
            if (delta !== 0) onChange(Math.max(0, value + delta));
          }}
          style={{
            position: 'absolute', inset: 0, cursor: 'ew-resize', zIndex: 4,
          }}
        />
        {/* Edge fades */}
        <div style={{
          position: 'absolute', left: 0, top: 0, bottom: 0, width: 40,
          background: `linear-gradient(90deg, ${theme.surface2}, transparent)`,
          pointerEvents: 'none', zIndex: 2,
        }}/>
        <div style={{
          position: 'absolute', right: 0, top: 0, bottom: 0, width: 40,
          background: `linear-gradient(-90deg, ${theme.surface2}, transparent)`,
          pointerEvents: 'none', zIndex: 2,
        }}/>
      </div>
    );
  };

  return (
    <div style={{
      width: '100%', minHeight: '100%', background: theme.bg, color: theme.ink,
      padding: '54px 20px 60px',
      display: 'flex', flexDirection: 'column', gap: 16,
    }}>
      {/* Header — with small ring */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
        <button style={{
          width: 40, height: 40, borderRadius: 20, border: 'none',
          background: theme.surface2, cursor: 'pointer',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>{Icon.close(theme.ink2)}</button>

        <div style={{ flex: 1, textAlign: 'center' }}>
          <div style={{
            fontFamily: MONO, fontSize: 10, letterSpacing: 1.2,
            color: theme.ink3, textTransform: 'uppercase',
          }}>Exercise 04 · 06</div>
          <div style={{
            fontFamily: DISPLAY, fontSize: 22, marginTop: 2,
            letterSpacing: -0.5, color: theme.ink,
          }}>Military Press</div>
        </div>

        {/* Small progress ring */}
        <div style={{ position: 'relative', width: 48, height: 48 }}>
          <svg width="48" height="48" viewBox="0 0 48 48" style={{ transform: 'rotate(-90deg)' }}>
            <circle cx="24" cy="24" r="22" fill="none" stroke={theme.line} strokeWidth="3"/>
            <circle cx="24" cy="24" r="22" fill="none" stroke={accent.solid} strokeWidth="3"
              strokeLinecap="round" strokeDasharray={circ} strokeDashoffset={dashOff}
              style={{ transition: 'stroke-dashoffset 0.5s cubic-bezier(.2,.9,.3,1)' }}/>
          </svg>
          <div style={{
            position: 'absolute', inset: 0,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontFamily: MONO, fontSize: 11, color: theme.ink, fontWeight: 600,
            fontFeatureSettings: '"tnum"',
          }}>{done}/{sets.length}</div>
        </div>
      </div>

      {/* SET DECK — horizontally stacked cards you can thumb through */}
      <div style={{
        display: 'flex', gap: 8, padding: '6px 0',
      }}>
        {sets.map((st, i) => (
          <button
            key={i}
            onClick={() => setCurrent(i)}
            style={{
              flex: 1, padding: '10px 8px', borderRadius: 14,
              background: i === current ? theme.ink : (st.complete ? theme.surface2 : theme.rowBg),
              color: i === current ? theme.bg : theme.ink,
              border: `1px solid ${i === current ? theme.ink : theme.line}`,
              cursor: 'pointer',
              display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 2,
              transition: 'all 0.2s',
              opacity: !st.complete && i !== current ? 1 : (st.complete && i !== current ? 0.55 : 1),
            }}
          >
            <div style={{
              fontFamily: MONO, fontSize: 9, letterSpacing: 0.8,
              opacity: 0.6, textTransform: 'uppercase',
            }}>Set {i+1}</div>
            <div style={{
              fontFamily: DISPLAY, fontSize: 18, letterSpacing: -0.3,
              fontFeatureSettings: '"tnum"',
              textDecoration: st.complete ? 'line-through' : 'none',
              textDecorationThickness: 1,
            }}>{st.weight}×{st.reps}</div>
            {st.complete && (
              <div style={{ width: 5, height: 5, borderRadius: 3,
                background: i === current ? accent.solid : accent.solid,
              }}/>
            )}
          </button>
        ))}
      </div>

      {/* HERO LOG CARD — big dual-value display with BIG +/- steppers */}
      <div style={{
        background: theme.rowBg, borderRadius: 28, padding: '22px 18px',
        border: `1px solid ${theme.line}`,
        display: 'flex', flexDirection: 'column', gap: 18,
      }}>
        {[['weight', 'Weight · lb', 5], ['reps', 'Reps', 1]].map(([field, label, step]) => (
          <div key={field} style={{
            display: 'flex', alignItems: 'center', gap: 12,
            padding: '4px 2px',
          }}>
            <button
              onClick={() => bump(field, -step)}
              style={{
                width: 64, height: 64, borderRadius: 32, border: 'none',
                background: theme.surface2, cursor: 'pointer',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                flexShrink: 0,
              }}
            ><svg width="22" height="22" viewBox="0 0 22 22"><rect x="4" y="10" width="14" height="2.5" rx="1.25" fill={theme.ink}/></svg></button>

            <div style={{
              flex: 1, textAlign: 'center',
              display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 2,
            }}>
              <div style={{
                fontFamily: MONO, fontSize: 10, letterSpacing: 1.2,
                color: theme.ink3, textTransform: 'uppercase',
              }}>{label}</div>
              <div style={{
                fontFamily: DISPLAY, fontSize: 64, fontWeight: 400,
                color: theme.ink, letterSpacing: -2.2, lineHeight: 1,
                fontFeatureSettings: '"tnum"',
              }}>{s[field]}</div>
            </div>

            <button
              onClick={() => bump(field, step)}
              style={{
                width: 64, height: 64, borderRadius: 32, border: 'none',
                background: theme.surface2, cursor: 'pointer',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                flexShrink: 0,
              }}
            ><svg width="22" height="22" viewBox="0 0 22 22"><rect x="4" y="10" width="14" height="2.5" rx="1.25" fill={theme.ink}/><rect x="9.75" y="4" width="2.5" height="14" rx="1.25" fill={theme.ink}/></svg></button>
          </div>
        ))}

        {/* Log button */}
        <button
          onClick={toggleCurrent}
          style={{
            height: 54, borderRadius: 27, border: 'none', cursor: 'pointer',
            background: s.complete ? theme.surface2 : accent.solid,
            color: s.complete ? theme.ink2 : accent.ink,
            fontFamily: SANS, fontSize: 15, fontWeight: 600, letterSpacing: -0.2,
          }}
        >{s.complete ? 'Mark incomplete' : `Log set ${current+1}`}</button>
      </div>

      {/* EDITORIAL TIMER */}
      <div style={{
        background: running ? accent.solid : theme.rowBg,
        color: running ? accent.ink : theme.ink,
        borderRadius: 24, padding: running ? 24 : 20,
        border: `1px solid ${running ? accent.solid : theme.line}`,
        transition: 'all 0.35s cubic-bezier(.2,.9,.3,1)',
        position: 'relative', overflow: 'hidden',
      }}>
        {running && (
          <div style={{
            position: 'absolute', inset: 0,
            background: `linear-gradient(90deg, rgba(0,0,0,0.08) ${timerProgress * 100}%, transparent ${timerProgress * 100}%)`,
            pointerEvents: 'none',
          }} />
        )}
        <div style={{
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          marginBottom: 10, position: 'relative',
        }}>
          <div style={{
            fontFamily: MONO, fontSize: 10, letterSpacing: 1,
            textTransform: 'uppercase',
            color: running ? accent.ink : theme.ink3,
          }}>Rest Timer</div>
          <div style={{
            fontFamily: MONO, fontSize: 10, letterSpacing: 1,
            color: running ? accent.ink : theme.ink3, opacity: 0.6,
          }}>{running ? 'active' : 'ready'}</div>
        </div>
        <div style={{
          display: 'flex', alignItems: 'flex-end', gap: 6,
          marginBottom: 16, position: 'relative',
        }}>
          <div style={{
            fontFamily: DISPLAY, fontSize: running ? 88 : 68, fontWeight: 400,
            letterSpacing: -3, lineHeight: 0.9,
            fontFeatureSettings: '"tnum"',
            transition: 'font-size 0.35s',
          }}>{remaining}</div>
          <div style={{
            fontFamily: DISPLAY, fontSize: 26, fontWeight: 400,
            paddingBottom: 6, opacity: 0.5,
          }}>s</div>
          <div style={{ flex: 1 }} />
          <div style={{ display: 'flex', gap: 8, paddingBottom: 4 }}>
            <button
              onClick={() => setRunning(!running)}
              style={{
                width: 44, height: 44, borderRadius: 22, border: 'none',
                background: running ? 'rgba(0,0,0,0.15)' : theme.ink,
                color: running ? accent.ink : theme.bg, cursor: 'pointer',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}
            >{running ? Icon.pause(running ? accent.ink : theme.bg) : Icon.play(theme.bg)}</button>
            <button
              onClick={() => { setRemaining(preset); setRunning(false); }}
              style={{
                width: 44, height: 44, borderRadius: 22, border: 'none',
                background: running ? 'rgba(0,0,0,0.1)' : theme.surface2,
                cursor: 'pointer',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}
            >{Icon.reset(running ? accent.ink : theme.ink2)}</button>
          </div>
        </div>
        <div style={{ display: 'flex', gap: 6, position: 'relative' }}>
          {[30, 60, 90, 120, 180, 300].map((sec) => {
            const selected = sec === preset;
            return (
              <button key={sec}
                onClick={() => { setPreset(sec); setRemaining(sec); setRunning(false); }}
                style={{
                  flex: 1, height: 34, borderRadius: 17, border: 'none',
                  cursor: 'pointer',
                  background: selected
                    ? (running ? 'rgba(0,0,0,0.2)' : theme.ink)
                    : (running ? 'rgba(0,0,0,0.06)' : theme.surface2),
                  color: selected
                    ? (running ? accent.ink : theme.bg)
                    : (running ? accent.ink : theme.ink2),
                  fontFamily: MONO, fontSize: 11, fontWeight: 500, letterSpacing: 0.3,
                }}
              >{sec}s</button>
            );
          })}
        </div>
      </div>

      {/* EDITORIAL-STYLE LAST SESSION */}
      <EditorialHistory theme={theme} accent={accent} />
    </div>
  );
}

function EditorialHistory({ theme, accent }) {
  const sets = [
    { reps: 12, w: 75, vol: 900 },
    { reps: 7,  w: 80, vol: 560 },
    { reps: 5,  w: 80, vol: 400 },
  ];
  const max = Math.max(...sets.map(s => s.vol));
  return (
    <div style={{
      background: theme.rowBg, borderRadius: 24,
      padding: 20, border: `1px solid ${theme.line}`,
    }}>
      <div style={{
        display: 'flex', alignItems: 'baseline', justifyContent: 'space-between',
        marginBottom: 16, paddingBottom: 12,
        borderBottom: `1px solid ${theme.line}`,
      }}>
        <div>
          <div style={{
            fontFamily: MONO, fontSize: 10, letterSpacing: 1,
            textTransform: 'uppercase', color: theme.ink3,
          }}>Last session · 2 Mar</div>
          <div style={{
            fontFamily: DISPLAY, fontSize: 20, color: theme.ink,
            marginTop: 2, letterSpacing: -0.4,
          }}>One week ago</div>
        </div>
        <div style={{ textAlign: 'right' }}>
          <div style={{
            fontFamily: MONO, fontSize: 10, letterSpacing: 1,
            color: theme.ink3, textTransform: 'uppercase',
          }}>Total vol</div>
          <div style={{
            fontFamily: DISPLAY, fontSize: 22, color: accent.solid,
            fontFeatureSettings: '"tnum"',
          }}>1,860<span style={{ fontSize: 13, opacity: 0.6, marginLeft: 3 }}>lb</span></div>
        </div>
      </div>
      {sets.map((s, i) => (
        <div key={i} style={{
          display: 'grid',
          gridTemplateColumns: '20px 1fr 50px 60px',
          alignItems: 'center', gap: 12,
          padding: '8px 0',
        }}>
          <div style={{ fontFamily: MONO, fontSize: 10, color: theme.ink3 }}>0{i+1}</div>
          <div style={{
            fontFamily: DISPLAY, fontSize: 16, color: theme.ink,
            fontFeatureSettings: '"tnum"',
          }}>{s.w} <span style={{ fontSize: 11, color: theme.ink3 }}>lb</span> × {s.reps}</div>
          <div style={{
            height: 4, background: theme.surface2, borderRadius: 2,
            overflow: 'hidden', position: 'relative',
          }}>
            <div style={{
              position: 'absolute', inset: 0, width: `${(s.vol/max)*100}%`,
              background: accent.solid, borderRadius: 2,
            }} />
          </div>
          <div style={{
            fontFamily: MONO, fontSize: 12, color: theme.ink2,
            textAlign: 'right', fontFeatureSettings: '"tnum"',
          }}>{s.vol} lb</div>
        </div>
      ))}
    </div>
  );
}

Object.assign(window, { WorkoutScreenSynthesis });
